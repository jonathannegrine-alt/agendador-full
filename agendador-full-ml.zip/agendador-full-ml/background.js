importScripts('pagina.js');

const sleep = ms => new Promise(r => setTimeout(r, ms));
const MAX_ENVIOS = 3;
const MAX_NOTIFS = 50;
const INTERVALO_MIN = { 1: 30, 2: 40, 3: 45 };
const DIAS_QUALQUER = 60;
const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
const ROTULO = { trava_fora: 'Nenhuma opção aceita o centro e o dia do grupo', indisp: 'Sem vaga', disp: 'VAGA ENCONTRADA', cd_nao_aceito: 'Centro fora da lista', erro: 'Erro (segue tentando)', deslogado: 'DESLOGADO' };

// Links montados sempre a partir do número do envio.
const linkAgenda = num => `https://vendedores.mercadolivre.com.br/shipping/inbounds/${num}/appointment-v2`;
const linkHub = num => `https://vendedores.mercadolivre.com.br/shipping/inbounds/${num}/hub`;
// Tela de sucesso: o ML já usou /hub-v2 e hoje usa /hub.
const ehHub = url => /\/inbounds\/\d+\/hub(-v2)?(?:[/?#]|$)/.test(url || '');
const GLOB_PADRAO = { intervalo: 60, ate: '', som: true, janelaId: null };

const ocupado = new Set();
let timerTick = null;

// ---------- filas (evitam escritas e marcações ao mesmo tempo) ----------
function criarFila() {
  let p = Promise.resolve();
  return fn => {
    const r = p.then(() => fn());
    p = r.catch(() => {});
    return r;
  };
}
const escrever = criarFila();
const marcarEmFila = criarFila();
const abaEmFila = criarFila();

// ---------- armazenamento ----------
async function lerGlob() {
  const { glob } = await chrome.storage.local.get('glob');
  return { ...GLOB_PADRAO, ...(glob || {}) };
}
const salvarGlob = patch => escrever(async () => {
  const g = { ...(await lerGlob()), ...patch };
  await chrome.storage.local.set({ glob: g });
  return g;
});
async function lerLista() {
  const { lista } = await chrome.storage.local.get('lista');
  return lista || [];
}
async function lerEnv(num) {
  const k = 'env_' + num;
  return (await chrome.storage.local.get(k))[k] || null;
}
const salvarEnv = (num, patch) => escrever(async () => {
  const e = await lerEnv(num);
  if (!e) return null;
  const novo = { ...e, ...patch };
  await chrome.storage.local.set({ ['env_' + num]: novo });
  return novo;
});
const registrar = (num, linhas) => escrever(async () => {
  const k = 'log_' + num;
  const atual = (await chrome.storage.local.get(k))[k] || [];
  const hora = new Date().toLocaleTimeString('pt-BR');
  const texto = [].concat(linhas).filter(Boolean).join(' · ');
  await chrome.storage.local.set({ [k]: [`[${hora}] ${texto}`, ...atual].slice(0, 40) });
});
async function todosEnvios() {
  const lista = await lerLista();
  return (await Promise.all(lista.map(lerEnv))).filter(Boolean);
}

// Termo de uso: sem aceite da versão atual, nada roda (igual no popup e no site).
const TERMO_VERSAO = 3;
async function termoOk() {
  const { termo } = await chrome.storage.local.get('termo');
  return !!termo && termo.versao === TERMO_VERSAO;
}

// ---------- conta (login por e-mail + código; servidor: servidor/supabase/functions/agendador-auth) ----------
const API = 'https://qasrccmtrllotukyeiax.supabase.co/functions/v1/agendador-auth';
const VALIDAR_A_CADA = 30 * 60 * 1000;      // confere a sessão no servidor a cada 30 min
const TOLERANCIA_OFFLINE = 24 * 3600 * 1000; // servidor fora do ar: vale a última validação de até 24 h
const VALIDADO_RECENTE = 2 * 60 * 1000;      // iniciar: aceita a validação feita na revisão (até 2 min)
const FIM_SESSAO = {
  outro_computador: 'Sua conta entrou em outro computador.',
  derrubado: 'O administrador encerrou o seu acesso.',
  bloqueado: 'Seu acesso foi bloqueado.',
  saiu: 'Você saiu da conta.',
  sessao_invalida: 'Seu acesso expirou.'
};

// Limite de 15 s: sem resposta, dá erro em vez de ficar esperando para sempre.
async function chamarAPI(acao, dados) {
  try {
    const r = await fetch(API, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ acao, ...dados }), signal: AbortSignal.timeout(15000) });
    return await r.json();
  } catch (err) {
    if (err && (err.name === 'TimeoutError' || err.name === 'AbortError')) throw new Error('o servidor demorou para responder. Tente de novo');
    throw err;
  }
}
async function lerConta() { return (await chrome.storage.local.get('conta')).conta || null; }
async function dispositivo() {
  let { dispositivo: d } = await chrome.storage.local.get('dispositivo');
  if (!d) { d = crypto.randomUUID(); await chrome.storage.local.set({ dispositivo: d }); }
  return d;
}

// A sessão acabou no servidor: para tudo e avisa uma vez.
async function perderConta(motivo) {
  const c = await lerConta();
  if (!c || !c.token) return;
  await escrever(() => chrome.storage.local.set({ conta: { email: c.email, nome: c.nome, token: null, motivo } }));
  const ativos = (await todosEnvios()).filter(e => e.ativo);
  for (const e of ativos) await parar(e.num, 'PARADO: ' + (FIM_SESSAO[motivo] || 'acesso encerrado.'));
  if (motivo !== 'saiu') {
    await notificar('', 'deslogado', '🔒 Agendador: ' + (FIM_SESSAO[motivo] || 'acesso encerrado'),
      `${FIM_SESSAO[motivo] || 'O seu acesso foi encerrado.'}${ativos.length ? `\n\nParei: ${ativos.map(e => '#' + e.num).join(', ')}.` : ''}\n\nPara voltar a usar neste computador, entre de novo com o seu e-mail e um código.`);
    tocar('falha');
  }
  await atualizarGeral();
}

// forcar = confere agora no servidor (antes de iniciar e antes de marcar).
async function contaOk(forcar) {
  const c = await lerConta();
  if (!c || !c.token) return false;
  if (!forcar && !c.semAssinatura && c.validadoEm && Date.now() - c.validadoEm < VALIDAR_A_CADA) return true;
  let r;
  try { r = await chamarAPI('validar', { token: c.token, ext_versao: chrome.runtime.getManifest().version }); }
  catch (err) { return !!c.validadoEm && Date.now() - c.validadoEm < TOLERANCIA_OFFLINE; }
  if (r && r.ok) {
    await escrever(async () => { const x = await lerConta(); if (x && x.token === c.token) await chrome.storage.local.set({ conta: { ...x, validadoEm: Date.now(), semAssinatura: false, assinatura: r.assinatura || null } }); });
    return true;
  }
  if (r && r.erro === 'sem_assinatura') { await semAssinatura(c, r.assinatura); return false; }
  if (r && r.erro && r.erro !== 'falha_servidor') { await perderConta(r.erro); return false; }
  if (c.semAssinatura) return false;
  return !!c.validadoEm && Date.now() - c.validadoEm < TOLERANCIA_OFFLINE;
}

// Assinatura vencida/cancelada: a sessão continua (não precisa entrar de novo depois de pagar); só para tudo e avisa uma vez.
async function semAssinatura(c, assinatura) {
  await escrever(async () => { const x = await lerConta(); if (x && x.token === c.token) await chrome.storage.local.set({ conta: { ...x, semAssinatura: true, assinatura: assinatura || null } }); });
  if (c.semAssinatura) return;
  const ativos = (await todosEnvios()).filter(e => e.ativo);
  for (const e of ativos) await parar(e.num, 'PARADO: a assinatura não está ativa.');
  await notificar('', 'deslogado', '🔒 Agendador: assinatura inativa',
    `A sua assinatura do Agendador Full não está ativa, então o monitoramento parou.${ativos.length ? `\n\nParei: ${ativos.map(e => '#' + e.num).join(', ')}.` : ''}\n\nAbra o Agendador e toque em "Assinar". Depois de pagar, é só iniciar de novo.`);
  tocar('falha');
  await atualizarGeral();
}

async function entrar(email, codigo) {
  email = String(email || '').trim().toLowerCase();
  const r = await chamarAPI('confirmar', {
    email, codigo: String(codigo || '').trim(), dispositivo: await dispositivo(),
    ext_versao: chrome.runtime.getManifest().version, termo_versao: TERMO_VERSAO
  });
  if (!r.ok) return r;
  const sem = !!r.assinatura && !r.assinatura.acesso;
  await escrever(() => chrome.storage.local.set({ conta: { email: r.email, nome: r.nome || '', token: r.token, validadoEm: sem ? 0 : Date.now(), semAssinatura: sem, assinatura: r.assinatura || null } }));
  await atualizarGeral();
  return { ok: true };
}

async function sair() {
  const c = await lerConta();
  if (c && c.token) await chamarAPI('sair', { token: c.token }).catch(() => null);
  await perderConta('saiu');
  return { ok: true };
}

const MAX_OPCOES = 3;
// Configuração = lista de até 3 opções, em ordem de preferência.
// Cada opção: forma de envio, centros (em ordem), dias e horários.
function cfgPadrao() { return { opcoes: [] }; }
function opcaoPadrao() {
  return { tipoEnvio: '', cds: [], datasModo: '', datas: [], datasN: 7, datasAte: null, horas: {} };
}
// Converte a configuração da v2.0/v2.1 (verde/amarelo) para opções.
function migrarCfg(c) {
  if (!c) return cfgPadrao();
  if (Array.isArray(c.opcoes)) return { opcoes: c.opcoes.slice(0, MAX_OPCOES).map(o => ({ ...opcaoPadrao(), ...o })) };
  const base = {
    ...opcaoPadrao(),
    tipoEnvio: c.tipoEnvio || 'Veículo particular',
    cds: c.cds || [],
    datasModo: c.datasModo || ((c.datas || []).length ? 'lista' : ''),
    datas: c.datas || [], datasN: c.datasN || 7, datasAte: c.datasAte || null
  };
  const pref = {}, aceito = {};
  for (const [h, v] of Object.entries(c.horas || {})) (v === 2 ? aceito : pref)[h] = 1;
  if (!Object.keys(pref).length && !Object.keys(aceito).length && !base.cds.length && !base.datasModo) return cfgPadrao();
  const opcoes = [{ ...base, horas: Object.keys(pref).length ? pref : aceito }];
  if (Object.keys(pref).length && Object.keys(aceito).length) opcoes.push({ ...clonar(base), horas: aceito });
  return { opcoes };
}
const clonar = o => JSON.parse(JSON.stringify(o));
function novoEnv(num, url) {
  return {
    num, url, criadoEm: Date.now(), cfg: cfgPadrao(),
    ativo: false, fase: 'parado', erros: 0,
    tabId: null, proxima: 0, ultima: null, ultimoStatus: null, resultado: null, agendaML: null,
    grupo: null, trava: null
  };
}

// ---------- utilidades ----------
const msgErro = e => (e && e.message) ? e.message : String(e);
const pad = n => String(n).padStart(2, '0');
const fmtData = d => `${pad(d.d)}/${pad(d.m)}`;
const curto = lbl => (lbl || '').replace(/^Centro log[íi]stico\s*/i, '').trim();
const horaDe = t => { const m = (t || '').match(/\d{1,2}/); return m ? parseInt(m[0], 10) : null; };
const codigoDe = lbl => ((lbl || '').toUpperCase().match(/BR[A-Z]{2}\d{2}/) || [''])[0];
const nomeDe = lbl => curto(lbl).replace(/\s*-\s*BR[A-Z]{2}\d{2}.*$/i, '').trim();
// O ML às vezes mostra só o código (" - BRRC03 Avenida ..."): usa o nome conhecido.
const NOMES_CD = { BRRC01: 'Perus', BRRC02: 'Sumaré', BRRC03: 'Embu das Artes', BRRC05: 'Itupeva' };
const nomeCd = lbl => nomeDe(lbl) || NOMES_CD[codigoDe(lbl)] || codigoDe(lbl);
const rotuloCd = lbl => codigoDe(lbl) ? `${nomeCd(lbl)} - ${codigoDe(lbl)}` : curto(lbl);
const hojeZero = () => { const h = new Date(); h.setHours(0, 0, 0, 0); return h; };
const somarDias = (dt, n) => { const x = new Date(dt); x.setDate(x.getDate() + n); return x; };
const paraObj = dt => ({ y: dt.getFullYear(), m: dt.getMonth() + 1, d: dt.getDate() });
const valorData = d => new Date(d.y, d.m - 1, d.d).getTime();

// ---------- centros aprendidos ----------
const aprenderCentros = lbls => escrever(async () => {
  const { centros = {} } = await chrome.storage.local.get('centros');
  let mudou = false;
  for (const l of lbls) {
    const cod = codigoDe(l);
    const nome = nomeDe(l);
    if (!cod || !nome) continue;
    if (!centros[cod] || centros[cod].nome !== nome) { centros[cod] = { nome, visto: Date.now() }; mudou = true; }
  }
  if (mudou) await chrome.storage.local.set({ centros });
});

// ---------- notificações ----------
// tipos: sucesso | reetiq | seguranca | deslogado | falha | prazo | dia
async function notificar(num, tipo, titulo, msg) {
  const n = { id: `n${Date.now()}${Math.random().toString(36).slice(2, 6)}`, ts: Date.now(), num: String(num), tipo, titulo, msg, lida: false };
  await escrever(async () => {
    const { notifs = [] } = await chrome.storage.local.get('notifs');
    await chrome.storage.local.set({ notifs: [n, ...notifs].slice(0, MAX_NOTIFS) });
  });
  chrome.notifications.create(n.id, {
    type: 'basic', iconUrl: 'icon128.png',
    title: titulo,
    message: 'Clique no ícone do Agendador Full para ver os detalhes.',
    priority: 2, requireInteraction: true
  });
  atualizarGeral();
}

async function tocar(som, forcar) {
  const g = await lerGlob();
  if (!g.som && !forcar) return;
  try {
    const existe = chrome.offscreen.hasDocument ? await chrome.offscreen.hasDocument() : false;
    if (!existe) {
      await chrome.offscreen.createDocument({
        url: 'offscreen.html', reasons: ['AUDIO_PLAYBACK'],
        justification: 'Tocar alerta quando o agendamento é marcado ou falha'
      });
    }
  } catch (e) { /* documento já existe */ }
  try { await chrome.runtime.sendMessage({ alvo: 'offscreen', som }); } catch (e) { /* sem receptor */ }
}

async function atualizarGeral() {
  const ativos = (await todosEnvios()).filter(e => e.ativo);
  const { notifs = [] } = await chrome.storage.local.get('notifs');
  const naoLidas = notifs.filter(n => !n.lida).length;
  const conta = await lerConta();
  if (naoLidas || !(await termoOk()) || !conta || !conta.token) {
    chrome.action.setBadgeText({ text: '!' });
    chrome.action.setBadgeBackgroundColor({ color: '#E0383E' });
  } else {
    chrome.action.setBadgeText({ text: ativos.length ? String(ativos.length) : '' });
    chrome.action.setBadgeBackgroundColor({ color: '#00A650' });
  }
  if (ativos.length) {
    chrome.power.requestKeepAwake('system');
    if (!(await chrome.alarms.get('tick'))) chrome.alarms.create('tick', { periodInMinutes: 0.5 });
    agendarTick(500);
  } else {
    chrome.power.releaseKeepAwake();
    await chrome.alarms.clear('tick');
  }
}

function agendarTick(ms) {
  clearTimeout(timerTick);
  timerTick = setTimeout(tick, ms);
}

// ---------- abas ----------
async function garantirAba(num) {
  const e = await lerEnv(num);
  const g = await lerGlob();
  let win = null;
  if (g.janelaId != null) {
    try { win = await chrome.windows.get(g.janelaId); } catch (err) { win = null; }
  }
  if (e.tabId != null && win) {
    try {
      const t = await chrome.tabs.get(e.tabId);
      if (t.windowId === win.id) return t.id;
    } catch (err) { /* aba fechada */ }
  }
  if (!win) {
    win = await chrome.windows.create({ url: linkAgenda(num), focused: false, state: 'normal', width: 1280, height: 900 });
    await salvarGlob({ janelaId: win.id });
    const tabId = win.tabs[0].id;
    await salvarEnv(num, { tabId });
    return tabId;
  }
  const t = await chrome.tabs.create({ windowId: win.id, url: linkAgenda(num), active: false });
  await salvarEnv(num, { tabId: t.id });
  return t.id;
}

async function passo(tabId, acao, a) {
  const [r] = await chrome.scripting.executeScript({
    target: { tabId }, func: fbPasso, args: [acao, a === undefined ? null : a]
  });
  return r ? r.result : undefined;
}

async function esperar(tabId, acao, a, cond, timeout, intervalo = 400) {
  const fim = Date.now() + timeout;
  while (Date.now() < fim) {
    try {
      const r = await passo(tabId, acao, a);
      if (cond(r)) return r;
    } catch (err) { /* página ainda carregando */ }
    await sleep(intervalo);
  }
  return null;
}

async function carregar(tabId, url) {
  await chrome.tabs.update(tabId, { url });
  await sleep(800);
  const fim = Date.now() + 30000;
  while (Date.now() < fim) {
    const t = await chrome.tabs.get(tabId);
    if (t.status === 'complete') return true;
    await sleep(400);
  }
  return false;
}

const URL_LOGIN = /\/jms\/|\/lgz\/|\/login|\/registration|auth\.mercadoli/i;
async function deslogado(tabId) {
  try {
    const t = await chrome.tabs.get(tabId);
    return URL_LOGIN.test(t.url || '');
  } catch (err) { return false; }
}

// Retorna true, false (não achou a opção) ou 'indisp' (o ML marcou como indisponível).
async function selecionarTipo(tabId, tipo) {
  const info = await passo(tabId, 'info');
  if (info && info.tipo.includes(tipo)) return true;
  await passo(tabId, 'abrirTipo');
  await sleep(800);
  const r = await passo(tabId, 'escolherTipo', tipo);
  if (r === 'indisp') { await passo(tabId, 'abrirTipo').catch(() => null); return 'indisp'; }
  if (!r) return false;
  await sleep(2000);
  return true;
}

async function irParaMes(tabId, m) {
  const alvo = MESES[m - 1];
  for (let i = 0; i < 8; i++) {
    const vis = await esperar(tabId, 'mes', null, r => Array.isArray(r) && r.length, 3000);
    if (!vis) return false;
    if (vis.includes(alvo)) return true;
    const atual = MESES.indexOf(vis[0]);
    const diff = ((m - 1) - atual + 12) % 12;
    if (!(await passo(tabId, 'navMes', diff <= 6 ? 'next' : 'prev'))) return false;
    await sleep(1000);
  }
  return false;
}

// Situação do envio no ML (página de preparação): data agendada, centro e prazo.
async function lerSituacao(num) {
  const tabId = await abaEmFila(() => garantirAba(num));
  await carregar(tabId, linkHub(num));
  if (await deslogado(tabId)) return { deslogado: true };
  const hub = await esperar(tabId, 'hub', null, r => r && (r.envio || r.carregado), 12000);
  return hub || {};
}

// ---------- datas ----------
// Converte a configuração em: período (ini..fim) ou lista de dias.
function periodo(cfg) {
  const hoje = hojeZero();
  const modo = cfg.datasModo || 'lista';
  if (modo === 'lista') {
    const lista = (cfg.datas || []).filter(d => valorData(d) >= hoje.getTime()).sort((a, b) => valorData(a) - valorData(b));
    return { modo, lista };
  }
  let fim;
  if (modo === 'proximos') fim = somarDias(hoje, Math.max(1, cfg.datasN || 7) - 1);
  else if (modo === 'ate' && cfg.datasAte) fim = new Date(cfg.datasAte.y, cfg.datasAte.m - 1, cfg.datasAte.d);
  else fim = somarDias(hoje, DIAS_QUALQUER);
  return { modo, ini: hoje, fim };
}

function mesesDoPeriodo(p) {
  const out = [];
  const add = (y, m) => { if (!out.some(x => x.y === y && x.m === m)) out.push({ y, m }); };
  if (p.lista) { p.lista.forEach(d => add(d.y, d.m)); return out; }
  let c = new Date(p.ini.getFullYear(), p.ini.getMonth(), 1);
  while (c <= p.fim && out.length < 4) { add(c.getFullYear(), c.getMonth() + 1); c = new Date(c.getFullYear(), c.getMonth() + 1, 1); }
  return out;
}

// ---------- checagem ----------
// Dentro de uma opção todos os horários valem igual: a prioridade é a ordem das opções.
function servem(horas, op, i, dt) {
  return horas
    .map(t => ({ t, h: horaDe(t), i, dt }))
    .filter(x => x.h !== null && op.horas[String(x.h)]);
}

async function clicarDia(tabId, dt) {
  if (!(await irParaMes(tabId, dt.m))) return 'mês não aparece';
  const st = await passo(tabId, 'dia', { d: dt.d, clicar: true });
  if (st !== 'ok') return st === 'indisp' ? 'indisponível' : 'não achei o dia';
  await sleep(1200);
  return 'ok';
}

async function checarCalendario(tabId, op, lbl, log) {
  await passo(tabId, 'abrirCalendario');
  const vis = await esperar(tabId, 'mes', null, r => Array.isArray(r) && r.length, 6000);
  if (!vis) return { erro: 'o calendário não abriu' };

  const p = periodo(op);
  if (p.lista && !p.lista.length) { log.push('todas as datas escolhidas já passaram'); return {}; }

  // 1) Descobre os dias liberados pelo ML dentro do período.
  const dias = [];
  for (const mes of mesesDoPeriodo(p)) {
    if (!(await irParaMes(tabId, mes.m))) { log.push(`${MESES[mes.m - 1]}: mês não aparece`); continue; }
    const livres = (await passo(tabId, 'diasDisponiveis')) || [];
    for (const d of livres) {
      const dt = { y: mes.y, m: mes.m, d };
      const v = valorData(dt);
      const dentro = p.lista
        ? p.lista.some(x => x.y === dt.y && x.m === dt.m && x.d === dt.d)
        : v >= p.ini.getTime() && v <= p.fim.getTime();
      if (dentro) dias.push(dt);
    }
  }
  dias.sort((a, b) => valorData(a) - valorData(b));
  if (!dias.length) { log.push('nenhum dia liberado no período'); return {}; }
  log.push('dias liberados: ' + dias.map(fmtData).join(', '));

  // 2) Do dia mais cedo para o mais tarde: o primeiro horário que serve é o escolhido.
  for (let i = 0; i < dias.length; i++) {
    const dt = dias[i];
    const st = await clicarDia(tabId, dt);
    if (st !== 'ok') { log.push(`${fmtData(dt)}: ${st}`); continue; }
    // Página lenta: os horários podem demorar. Espera até 10 s; se vier vazio, clica no dia de novo.
    let horas = (await esperar(tabId, 'horas', null, r => Array.isArray(r) && r.length, 10000)) || [];
    if (!horas.length && (await clicarDia(tabId, dt)) === 'ok') {
      horas = (await esperar(tabId, 'horas', null, r => Array.isArray(r) && r.length, 8000)) || [];
    }
    if (!horas.length) {
      log.push(`${fmtData(dt)}: dia liberado, mas os horários não carregaram`);
      (log.diasSemHora = log.diasSemHora || []).push(fmtData(dt));   // lido em rodar(): recheca rápido e avisa
      continue;
    }
    const ok = servem(horas, op, i, dt).sort((a, b) => a.h - b.h || horaMin(a.t) - horaMin(b.t));
    log.push(`${fmtData(dt)}: [${horas.join(', ') || '-'}] → ${ok.length} serve(m)`);
    if (!ok.length) continue;
    const c = ok[0];
    if (!(await passo(tabId, 'marcarAlvo', c.t))) return { erro: 'o horário sumiu da lista' };
    return { alvo: { cd: rotuloCd(lbl), cod: codigoDe(lbl), data: fmtData(c.dt), y: c.dt.y, m: c.dt.m, dia: c.dt.d, hora: c.t, h: c.h } };
  }
  return {};
}
const horaMin = t => { const m = (t || '').match(/(\d{1,2}):(\d{2})/); return m ? (+m[1]) * 60 + (+m[2]) : 0; };

// Abre a página de agendamento do zero e escolhe a forma de envio da opção.
async function abrirAgendamento(tabId, num, tipo) {
  await carregar(tabId, linkAgenda(num));
  if (await deslogado(tabId)) return { status: 'deslogado' };
  let info = await esperar(tabId, 'info', null, r => r && (r.trigger || r.semDatas || r.login), 15000);
  if (info && info.login) return { status: 'deslogado' };
  if (!info) {
    if (await deslogado(tabId)) return { status: 'deslogado' };
    return { status: 'erro', msg: 'a página não carregou o agendamento' };
  }
  if (!info.url.includes(num)) return { status: 'erro', msg: `trava: a aba não está no envio ${num}` };
  if (info.semDatas && !info.trigger) return { status: 'semDatas' };
  const st = await selecionarTipo(tabId, tipo);
  if (st === 'indisp') return { status: 'tipoIndisp' };
  if (!st) {
    const ag = await passo(tabId, 'info').catch(() => null);
    if (ag && ag.semDatas) return { status: 'semDatas' };
    return { status: 'erro', msg: `forma de envio "${tipo}" não encontrada` };
  }
  info = await esperar(tabId, 'info', null, r => r && (r.centros.length || r.campo || r.semDatas), 12000);
  if (!info) return { status: 'erro', msg: 'nem a lista de centros nem o calendário apareceram' };
  aprenderCentros([...info.centros, info.centroFixo].filter(Boolean));
  if (info.semDatas && !info.centros.length && !info.campo) return { status: 'semDatas' };
  return { status: 'ok', info };
}

// Uma opção: forma de envio → centros na ordem → dias do mais cedo → primeiro horário que serve.
async function checarOpcao(tabId, num, op, log) {
  const ab = await abrirAgendamento(tabId, num, op.tipoEnvio);
  if (ab.status === 'deslogado') return { deslogado: true };
  if (ab.status === 'semDatas') { log.push('ML: "Não temos datas disponíveis no momento"'); return {}; }
  if (ab.status === 'tipoIndisp') { log.push(`forma de envio "${op.tipoEnvio}" indisponível no ML agora`); return {}; }
  if (ab.status === 'erro') return { erro: ab.msg };

  const info = ab.info;
  const aceito = lbl => op.cds.some(c => lbl.toUpperCase().includes(c.toUpperCase()));

  if (info.centros.length) {
    const ordem = [];
    for (const c of op.cds) {
      const l = info.centros.find(x => x.toUpperCase().includes(c.toUpperCase()));
      if (l && !ordem.includes(l)) ordem.push(l);
    }
    if (!ordem.length) { log.push('centros oferecidos fora da lista: ' + info.centros.map(nomeDe).join(', ')); return { cdNao: true }; }
    let erro = null;
    for (let i = 0; i < ordem.length; i++) {
      const lbl = ordem[i];
      if (i > 0) {
        const ab2 = await abrirAgendamento(tabId, num, op.tipoEnvio);
        if (ab2.status === 'deslogado') return { deslogado: true };
        if (ab2.status !== 'ok' || !ab2.info.centros.length) break;
      }
      log.push(nomeCd(lbl) + ' (' + codigoDe(lbl) + ')');
      if (!(await passo(tabId, 'clicarCentro', lbl))) { log.push('centro sumiu da lista'); continue; }
      await sleep(800);
      await passo(tabId, 'continuar');
      const cal = await esperar(tabId, 'info', null, r => r && (r.campo || r.semDatas), 10000);
      if (!cal) { log.push('calendário não apareceu'); continue; }
      if (!cal.campo) { log.push('sem datas no momento'); continue; }
      const res = await checarCalendario(tabId, op, lbl, log);
      if (res.alvo) return res;
      if (res.erro) erro = res.erro;
    }
    return erro ? { erro } : {};
  }

  const lbl = info.centroFixo;
  if (!lbl) return { erro: 'não consegui ler o centro logístico (por segurança, não marco)' };
  if (!aceito(lbl)) { log.push('centro da página fora da lista: ' + nomeDe(lbl) + ' (' + codigoDe(lbl) + ')'); return { cdNao: true }; }
  log.push(nomeCd(lbl) + ' (' + codigoDe(lbl) + ')');
  return checarCalendario(tabId, op, lbl, log);
}

// ---------- envios vinculados ----------
// Depois que um envio do grupo marcou, os outros só aceitam o mesmo centro e o mesmo dia
// (nos horários de cada um). Opção sem esse centro ou sem esse dia é pulada.
function aplicarTrava(op, t) {
  if (!(op.cds || []).some(c => c.toUpperCase() === t.cd)) return null;
  const p = periodo(op), v = valorData(t.data);
  const dentro = p.lista ? p.lista.some(x => valorData(x) === v) : v >= p.ini.getTime() && v <= p.fim.getTime();
  if (!dentro) return null;
  return { ...op, cds: [t.cd], datasModo: 'lista', datas: [t.data] };
}
const bateTrava = (alvo, t) => alvo.cod === t.cd && alvo.y === t.data.y && alvo.m === t.data.m && alvo.dia === t.data.d;
const txtTrava = t => `${t.nome} (${t.cd}) no dia ${fmtData(t.data)}`;

// "segunda-feira, 26 de outubro, às 6:00h" + "Perus - BRRC01" → trava (ou null).
function travaDeTexto(quando, centro, de) {
  const cd = codigoDe(centro);
  const m = String(quando || '').match(/(\d{1,2}) de ([a-zç]+)/i);
  const mes = m ? MESES.indexOf(m[2].toLowerCase()) + 1 : 0;
  if (!cd || !mes) return null;
  const hoje = hojeZero();
  let y = hoje.getFullYear();
  if (new Date(y, mes - 1, +m[1]) < somarDias(hoje, -60)) y++;
  return { cd, nome: nomeCd(centro), data: { y, m: mes, d: +m[1] }, de };
}

// O envio que marcou trava os outros do grupo que ainda não têm trava.
async function travarGrupo(num, alvo) {
  const e = await lerEnv(num);
  if (!e || !e.grupo) return [];
  if (!alvo.cod) { await registrar(num, 'GRUPO: não consegui ler o código do centro; os envios vinculados NÃO foram travados.'); return []; }
  const trava = { cd: alvo.cod, nome: nomeDe(alvo.cd) || alvo.cod, data: { y: alvo.y, m: alvo.m, d: alvo.dia }, de: num };
  const outros = (await todosEnvios()).filter(o => o.num !== num && o.grupo === e.grupo && !o.trava && o.fase !== 'agendado');
  for (const o of outros) {
    await salvarEnv(o.num, { trava });
    await registrar(o.num, `GRUPO: o #${num} marcou em ${txtTrava(trava)}. Agora só aceito esse centro e esse dia.`);
  }
  return outros.map(o => o.num);
}

// Na revisão: se um envio do grupo já está agendado (pela extensão ou direto no ML), ele define a trava.
async function travaPorParceiro(num, lerML = true) {
  const e = await lerEnv(num);
  if (!e || !e.grupo || e.trava) return;
  for (const o of (await todosEnvios()).filter(x => x.num !== num && x.grupo === e.grupo)) {
    let t = null;
    if (o.fase === 'agendado' && o.resultado) t = travaDeTexto(o.resultado.quando, o.resultado.centro, o.num);
    else if (lerML && !o.ativo && !ocupado.has(o.num)) {
      const s = await lerSituacao(o.num).catch(() => ({}));
      if (s.envio) {
        await salvarEnv(o.num, { agendaML: { envio: s.envio, centro: s.centro || '', prazo: s.prazo || '', ts: Date.now() } });
        t = travaDeTexto(s.envio, s.centro, o.num);
      }
    }
    if (t) {
      await salvarEnv(num, { trava: t });
      await registrar(num, `GRUPO: o #${o.num} já está agendado em ${txtTrava(t)}. Só aceito esse centro e esse dia.`);
      return;
    }
  }
}

async function vincular(num, com, ligar) {
  const a = await lerEnv(num), b = await lerEnv(com);
  if (!a || !b || num === com) return { ok: false, erro: 'Envio não encontrado.' };
  if (a.ativo) return { ok: false, erro: 'Pare o monitoramento deste envio antes de mudar o vínculo.' };
  const todos = await todosEnvios();
  if (ligar) {
    const gid = a.grupo || b.grupo || ('g' + Date.now());
    for (const x of todos) {
      if (x.num === num || x.num === com || (a.grupo && x.grupo === a.grupo) || (b.grupo && x.grupo === b.grupo)) await salvarEnv(x.num, { grupo: gid });
    }
    // Se um do grupo já foi agendado pela extensão, a trava vale na hora (o ML é lido na revisão).
    for (const x of await todosEnvios()) if (x.grupo === gid && x.fase !== 'agendado') await travaPorParceiro(x.num, false);
  } else {
    await salvarEnv(com, { grupo: null, trava: null });
    const resto = todos.filter(x => x.num !== com && a.grupo && x.grupo === a.grupo);
    for (const x of resto) {
      if (resto.length < 2) await salvarEnv(x.num, { grupo: null, trava: null });
      else if (x.trava && x.trava.de === com) await salvarEnv(x.num, { trava: null });
    }
  }
  return { ok: true };
}

async function checar(num) {
  const e = await lerEnv(num);
  const opcoes = migrarCfg(e.cfg).opcoes;
  if (!opcoes.length) return { status: 'erro', log: ['nenhuma opção configurada'] };
  const log = [];
  const t = e.grupo && e.trava;
  if (t) log.push(`GRUPO: só ${txtTrava(t)} (o #${t.de} marcou lá)`);
  const usar = opcoes.map((op, i) => {
    if (!t) return op;
    const x = aplicarTrava(op, t);
    if (!x) log.push(`OPÇÃO ${i + 1}: não aceita esse centro ou esse dia (pulada)`);
    return x;
  });
  if (!usar.some(Boolean)) return { status: 'trava_fora', log };
  const tabId = await abaEmFila(() => garantirAba(num));
  let houveErro = null, soCdNao = true;
  for (let i = 0; i < usar.length; i++) {
    if (!usar[i]) continue;
    log.push(`OPÇÃO ${i + 1}:`);
    const r = await checarOpcao(tabId, num, usar[i], log);
    if (r.deslogado) return { status: 'deslogado', log: ['O Mercado Livre pediu login'] };
    if (r.alvo) return { status: 'disp', alvo: { ...r.alvo, opcao: i + 1 }, log, tabId };
    if (r.erro) { houveErro = r.erro; log.push('erro: ' + r.erro); }
    if (!r.cdNao) soCdNao = false;
  }
  if (houveErro) return { status: 'erro', log };
  if (soCdNao) return { status: 'cd_nao_aceito', log };
  return { status: 'indisp', log };
}

// ---------- marcação ----------
async function cliqueReal(tabId, p) {
  const alvo = { tabId };
  await chrome.debugger.sendCommand(alvo, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x: p.x, y: p.y });
  await chrome.debugger.sendCommand(alvo, 'Input.dispatchMouseEvent', { type: 'mousePressed', x: p.x, y: p.y, button: 'left', clickCount: 1 });
  await sleep(60);
  await chrome.debugger.sendCommand(alvo, 'Input.dispatchMouseEvent', { type: 'mouseReleased', x: p.x, y: p.y, button: 'left', clickCount: 1 });
}

async function clicarElemento(tabId, qual) {
  if (!(await passo(tabId, 'rolar', qual))) return false;
  await sleep(400);
  const p = await passo(tabId, 'rect', qual);
  if (!p) return false;
  await cliqueReal(tabId, p);
  return true;
}

async function marcar(num, tabId, alvo) {
  let anexado = false;
  try {
    const tab = await chrome.tabs.get(tabId);
    if (!tab.url.includes(num)) return { erro: `trava: a aba saiu do envio ${num}` };

    await chrome.windows.update(tab.windowId, { focused: true, state: 'normal' });
    await chrome.tabs.update(tabId, { active: true });
    try {
      await chrome.tabs.setZoomSettings(tabId, { mode: 'automatic', scope: 'per-tab' });
      await chrome.tabs.setZoom(tabId, 1);
    } catch (err) { /* zoom não pôde ser ajustado */ }

    await chrome.debugger.attach({ tabId }, '1.3');
    anexado = true;
    await sleep(900);

    if (!(await clicarElemento(tabId, 'alvo'))) return { erro: 'o horário não está mais na tela' };
    await sleep(900);
    if (!(await clicarElemento(tabId, 'confirmar'))) return { erro: 'botão Confirmar do calendário não encontrado' };
    await sleep(1300);

    const valor = (await passo(tabId, 'valorData')) || '';
    const mh = valor.match(/(\d{1,2}):\d{2}/);
    const okHora = mh && parseInt(mh[1], 10) === alvo.h;
    const okDia = new RegExp(`\\b${alvo.dia}\\s+de\\b`, 'i').test(valor);
    if (!okHora || !okDia) return { erro: `o campo de data ficou "${valor || 'vazio'}"` };

    if (!(await passo(tabId, 'confirmarPrincipal'))) return { erro: 'botão Confirmar principal não encontrado' };
    await sleep(2500);

    let reetiq = false;
    let v = await passo(tabId, 'verificar').catch(() => null);
    if (v && v.reetiq && !v.hub) {
      reetiq = true;
      await passo(tabId, 'confirmarModal').catch(() => null);
      await sleep(2500);
      v = await passo(tabId, 'verificar').catch(() => null);
    }
    if (v && v.stale) return { stale: true };

    let hub = null;
    for (let i = 0; i < 25 && !hub; i++) {
      await sleep(1000);
      const t = await chrome.tabs.get(tabId);
      if (ehHub(t.url) && t.status === 'complete') {
        await sleep(2000);
        hub = await passo(tabId, 'hub').catch(() => null);
      }
    }
    // Plano B: o Confirmar já foi clicado, então confere direto na página do envio.
    if (!hub || !hub.envio) {
      await carregar(tabId, linkHub(num));
      await sleep(2500);
      hub = await esperar(tabId, 'hub', null, r => r && r.envio, 10000);
    }
    if (!hub || !hub.envio) return { incerto: true, erro: 'cliquei em Confirmar, mas não consegui ler a confirmação do ML' };
    const mh2 = hub.envio.match(/(\d{1,2}):\d{2}/);
    const bate = new RegExp(`\\b${alvo.dia}\\s+de\\b`, 'i').test(hub.envio) && mh2 && parseInt(mh2[1], 10) === alvo.h;
    if (!bate) return { incerto: true, erro: `o ML mostra "${hub.envio}", diferente do horário que tentei (${alvo.data} às ${alvo.hora})` };
    return { ok: true, reetiq: reetiq || hub.etiquetas, hub };
  } catch (err) {
    return { erro: msgErro(err) };
  } finally {
    if (anexado) await chrome.debugger.detach({ tabId }).catch(() => {});
  }
}

async function tratarMarcacao(num, alvo, r) {
  if (r.ok) {
    const quando = r.hub.envio.replace(/^Você vai enviar estoque\s*/i, '') || `${alvo.data} às ${alvo.hora}`;
    const centro = (nomeDe(r.hub.centro) ? curto(r.hub.centro).replace(/(\s*-\s*BR[A-Z]{2}\d{2})+$/i, m => ' - ' + codigoDe(m)) : '') || alvo.cd;
    const resumo = `${quando} — ${centro}`;
    await salvarEnv(num, {
      ativo: false, fase: 'agendado',
      resultado: { resumo, quando, centro, prazo: r.hub.prazo || '', reetiq: !!r.reetiq, ts: Date.now() }
    });
    await registrar(num, ['✅ AGENDADO: ' + resumo, r.reetiq ? '⚠️ PRECISA REETIQUETAR' : '']);
    let msg = `Agendado para ${quando}, em ${centro} (opção ${alvo.opcao}).`;
    if (r.reetiq) msg += '\n\n⚠️ O centro mudou: as etiquetas atuais não valem mais. Informe as caixas, baixe as etiquetas novas e cole em todos os volumes.';
    if (r.hub.prazo) msg += `\n\n${r.hub.prazo}`;
    const travados = (await todosEnvios()).filter(o => o.trava && o.trava.de === num && o.num !== num);
    if (travados.length) msg += `\n\n🔗 Envios vinculados (${travados.map(o => '#' + o.num).join(', ')}): agora só aceitam ${txtTrava(travados[0].trava)}.`;
    msg += '\n\nPróximos passos: revisar a preparação, etiquetar os volumes, emitir a NF-e e baixar a autorização de entrada. Chegue no horário: o ML recusa atrasos.';
    await notificar(num, r.reetiq ? 'reetiq' : 'sucesso',
      r.reetiq ? `✅ Envio ${num} agendado — ⚠️ REETIQUETAR` : `✅ Envio ${num} agendado`, msg);
    await atualizarGeral();
    tocar('sucesso');
    return;
  }
  if (r.incerto) {
    // Depois de clicar no Confirmar principal, não arrisca marcar de novo (poderia editar a reserva).
    await salvarEnv(num, { ativo: false, fase: 'parado' });
    await registrar(num, `⚠️ PAREI por segurança: ${r.erro}. Confira o envio no ML.`);
    await notificar(num, 'seguranca', `⚠️ Envio ${num}: confira no Mercado Livre`,
      `Parei por segurança: ${r.erro}.\n\nCliquei em Confirmar, mas não consegui confirmar o resultado. Para não editar a reserva por engano, não vou tentar de novo. Abra o envio no ML e confira a data e o horário.`);
    await atualizarGeral();
    tocar('falha');
    return;
  }
  if (r.stale) {
    await registrar(num, 'O ML disse que o horário não está mais disponível. Rechecando agora.');
    await salvarEnv(num, { fase: 'monitorando', proxima: 0 });
    agendarTick(300);
    return;
  }
  await registrar(num, `Falha ao marcar: ${r.erro}. Continuo monitorando.`);
  await salvarEnv(num, { fase: 'monitorando' });
  await notificar(num, 'falha', `❌ Envio ${num}: vaga achada, mas não consegui marcar`,
    `${alvo.data} às ${alvo.hora} em ${alvo.cd} (opção ${alvo.opcao}).\n\nMotivo: ${r.erro}.\n\nNada foi confirmado no ML. Continuo monitorando e tento na próxima vaga.`);
  tocar('falha');
}

// ---------- ciclo ----------
async function rodar(num, simular, intervaloMs) {
  if (ocupado.has(num) || !(await termoOk()) || !(await contaOk(false))) return;
  ocupado.add(num);
  try {
    await salvarEnv(num, simular ? { fase: 'testando' } : { proxima: Date.now() + intervaloMs });
    let res;
    try { res = await checar(num); } catch (err) { res = { status: 'erro', log: ['Falha: ' + msgErro(err)] }; }

    await registrar(num, [(simular ? 'TESTE · ' : '') + ROTULO[res.status], ...(res.log || [])]);
    const e = await salvarEnv(num, { ultima: Date.now(), ultimoStatus: res.status });
    if (!e) return;

    if (simular) {
      await salvarEnv(num, { fase: e.ativo ? 'monitorando' : 'parado' });
      if (res.status === 'disp') await registrar(num, `TESTE: eu marcaria ${res.alvo.data} às ${res.alvo.hora} em ${res.alvo.cd} (opção ${res.alvo.opcao}). Nada foi confirmado.`);
      return;
    }

    // Dia do período liberado, mas os horários não carregaram (página lenta): recheca em 10 s
    // (até 3 vezes seguidas) e avisa o usuário uma vez (repete só se mudar o dia ou depois de 30 min).
    const semHora = (res.log && res.log.diasSemHora) || [];
    if (res.status !== 'disp' && semHora.length) {
      const rapidas = (e.rapidas || 0) + 1, chave = semHora.join(', ');
      const avisar = !e.avisoDias || e.avisoDias.chave !== chave || Date.now() - e.avisoDias.ts > 30 * 60000;
      await salvarEnv(num, {
        rapidas,
        ...(rapidas <= 3 ? { proxima: Date.now() + 10000 } : {}),
        ...(avisar ? { avisoDias: { chave, ts: Date.now() } } : {})
      });
      if (rapidas <= 3) await registrar(num, 'Dia liberado sem horário lido: checo de novo em 10 s.');
      if (avisar) {
        await notificar(num, 'dia', `📅 Envio ${num}: abriu vaga em ${chave}`,
          `O Mercado Livre liberou ${chave} no período que você escolheu, mas a página demorou e não consegui ler os horários.\n\nSigo tentando marcar sozinho. Se quiser garantir, abra o envio no Mercado Livre e marque você mesmo.`);
        tocar('sucesso');
      }
    } else if (e.rapidas) await salvarEnv(num, { rapidas: 0 });

    if (res.status === 'deslogado') {
      await escrever(async () => {
        const x = await lerEnv(num);
        if (x) await chrome.storage.local.set({ ['env_' + num]: { ...x, ativo: false, fase: 'deslogado' } });
      });
      await registrar(num, 'PARADO: o Mercado Livre deslogou. Entre de novo e clique em Iniciar.');
      await notificar(num, 'deslogado', `🔒 Envio ${num}: o Mercado Livre deslogou`,
        'O monitoramento parou porque o Mercado Livre pediu login.\n\nEntre de novo no ML neste Chrome e clique em "Iniciar monitoramento" no envio.');
      await atualizarGeral();
      tocar('falha');
      return;
    }

    // Erros não param nada: só conta e segue recarregando no próximo ciclo.
    if (res.status === 'erro') { await salvarEnv(num, { erros: (e.erros || 0) + 1 }); return; }
    if (e.erros) await salvarEnv(num, { erros: 0 });

    if (res.status === 'disp') {
      const atual = await lerEnv(num);
      if (!atual || !atual.ativo) return;
      // Antes de marcar, confere no servidor se este computador ainda é o da conta.
      if (!(await contaOk(true))) { await registrar(num, 'Vaga achada, mas o acesso desta conta não está válido. Nada foi marcado.'); return; }
      await salvarEnv(num, { fase: 'marcando' });
      await registrar(num, `VAGA (opção ${res.alvo.opcao}): ${res.alvo.data} às ${res.alvo.hora} — ${res.alvo.cd}. Marcando…`);
      // Dentro da fila: se outro envio do grupo marcou enquanto este esperava, confere a trava de novo.
      const r = await marcarEmFila(async () => {
        const x = await lerEnv(num);
        if (x && x.grupo && x.trava && !bateTrava(res.alvo, x.trava)) return { pulou: `o #${x.trava.de} marcou em ${txtTrava(x.trava)}` };
        const m = await marcar(num, res.tabId, res.alvo);
        if (m.ok || m.incerto) await travarGrupo(num, res.alvo);
        return m;
      });
      if (r.pulou) {
        await registrar(num, `Vaga ignorada: ${r.pulou}. Rechecando só esse centro e esse dia.`);
        await salvarEnv(num, { fase: 'monitorando', proxima: 0 });
        agendarTick(300);
        return;
      }
      await tratarMarcacao(num, res.alvo, r);
    }
  } finally {
    ocupado.delete(num);
  }
}

async function tick() {
  const g = await lerGlob();
  const ativos = (await todosEnvios()).filter(e => e.ativo);
  if (!ativos.length || !(await termoOk()) || !(await contaOk(false))) return;

  if (g.ate && Date.now() > new Date(g.ate).getTime()) {
    for (const e of ativos) await parar(e.num, 'Horário limite atingido. Parado.');
    await notificar('', 'prazo', '⏰ Horário limite atingido',
      `Cheguei ao horário limite configurado ("Parar às") sem encontrar vaga. Parei: ${ativos.map(e => '#' + e.num).join(', ')}.`);
    tocar('falha');
    return;
  }

  const intervaloMs = Math.max(g.intervalo || 60, INTERVALO_MIN[ativos.length] || 45) * 1000;
  for (const e of ativos) {
    if (ocupado.has(e.num)) continue;
    if (e.proxima && Date.now() < e.proxima) continue;
    rodar(e.num, false, intervaloMs);
  }
  agendarTick(5000);
}

// ---------- ações vindas do popup ----------
async function adicionar({ num, url }) {
  num = String(num || '').replace(/\D/g, '');
  if (num.length < 5) return { ok: false, erro: 'Número de envio inválido.' };
  return escrever(async () => {
    const lista = await lerLista();
    if (lista.includes(num)) return { ok: false, erro: `O envio ${num} já está na lista.` };
    if (lista.length >= MAX_ENVIOS) return { ok: false, erro: 'Limite de 3 envios ao mesmo tempo.' };
    if (url && !url.includes(num)) return { ok: false, erro: 'O número não aparece no link desta aba.' };
    lista.push(num);
    await chrome.storage.local.set({ lista, ['env_' + num]: novoEnv(num, linkAgenda(num)), ['log_' + num]: [] });
    return { ok: true };
  });
}

async function remover(num) {
  const e = await lerEnv(num);
  if (e && e.ativo) await parar(num);
  if (e && e.tabId != null) {
    const g = await lerGlob();
    try {
      const t = await chrome.tabs.get(e.tabId);
      if (t.windowId === g.janelaId) await chrome.tabs.remove(e.tabId);
    } catch (err) { /* já fechada */ }
  }
  await escrever(async () => {
    const lista = (await lerLista()).filter(n => n !== num);
    await chrome.storage.local.set({ lista });
    await chrome.storage.local.remove(['env_' + num, 'log_' + num]);
  });
  await atualizarGeral();
  return { ok: true };
}

async function situacao(num) {
  // Já confere o login agora, enquanto lê a página: no "iniciar" ele já está validado.
  contaOk(true).catch(() => {});
  try {
    const s = await lerSituacao(num);
    if (s.deslogado) return { ok: false, erro: 'O Mercado Livre pediu login. Entre de novo e tente outra vez.' };
    const agendaML = { envio: s.envio || '', centro: s.centro || '', prazo: s.prazo || '', ts: Date.now() };
    await salvarEnv(num, { agendaML });
    await travaPorParceiro(num).catch(() => {});
    return { ok: true, ...agendaML };
  } catch (err) {
    return { ok: false, erro: msgErro(err) };
  }
}

// Toda falha ao iniciar fica no histórico do envio, com o motivo.
async function iniciar(num) {
  let r;
  try { r = await iniciarAgora(num); } catch (err) { r = { ok: false, erro: 'erro interno: ' + msgErro(err) }; }
  if (!r.ok && (await lerEnv(num))) await registrar(num, 'NÃO INICIOU: ' + r.erro);
  return r;
}
async function iniciarAgora(num) {
  const e = await lerEnv(num);
  if (!e) return { ok: false, erro: 'Envio não encontrado.' };
  if (e.ativo) return { ok: true };
  if (!(await termoOk())) return { ok: false, erro: 'Aceite o termo de uso antes de iniciar.' };
  const c = await lerConta();
  if (!c || !c.token) return { ok: false, erro: 'Entre com o seu e-mail antes de iniciar.' };
  const recente = !c.semAssinatura && c.validadoEm && Date.now() - c.validadoEm < VALIDADO_RECENTE;
  if (!recente && !(await contaOk(true))) {
    if ((await lerConta() || {}).semAssinatura) return { ok: false, erro: 'a assinatura não está ativa. Toque em "Assinar" na tela inicial.' };
    return { ok: false, erro: 'o servidor não confirmou o seu login (validado há ' + Math.round((Date.now() - (c.validadoEm || 0)) / 60000) + ' min).' };
  }
  const g = await lerGlob();
  if (g.ate && Date.now() > new Date(g.ate).getTime()) return { ok: false, erro: 'O horário limite já passou. Ajuste "Parar às".' };
  await salvarEnv(num, { ativo: true, fase: 'monitorando', erros: 0, resultado: null, proxima: 0 });
  await registrar(num, 'Monitoramento iniciado');
  await atualizarGeral();
  return { ok: true };
}

async function parar(num, motivo) {
  await escrever(async () => {
    const e = await lerEnv(num);
    if (!e) return;
    e.ativo = false;
    if (e.fase !== 'agendado') e.fase = 'parado';
    await chrome.storage.local.set({ ['env_' + num]: e });
  });
  if (motivo) await registrar(num, motivo);
  await atualizarGeral();
  return { ok: true };
}

const marcarLidas = ids => escrever(async () => {
  const { notifs = [] } = await chrome.storage.local.get('notifs');
  await chrome.storage.local.set({ notifs: notifs.map(n => (!ids || ids.includes(n.id)) ? { ...n, lida: true } : n) });
});

const salvarCentroManual = (cod, nome) => escrever(async () => {
  const { centros = {} } = await chrome.storage.local.get('centros');
  centros[cod] = { nome: nome || (centros[cod] && centros[cod].nome) || cod, visto: Date.now(), manual: true };
  await chrome.storage.local.set({ centros });
});

chrome.runtime.onMessage.addListener((msg, _sender, responder) => {
  if (!msg || msg.alvo === 'offscreen') return false;
  (async () => {
    switch (msg.tipo) {
      case 'adicionar': return adicionar(msg);
      case 'remover': return remover(msg.num);
      case 'cfg': {
        const e = await lerEnv(msg.num);
        if (e && !e.ativo) await salvarEnv(msg.num, { cfg: msg.cfg });
        return { ok: true };
      }
      case 'glob': await salvarGlob(msg.patch); agendarTick(500); return { ok: true };
      case 'situacao': return situacao(msg.num);
      case 'iniciar': return iniciar(msg.num);
      case 'diag': if (await lerEnv(msg.num)) await registrar(msg.num, 'DIAG: ' + msg.txt); return { ok: true };
      case 'logFalha': if (await lerEnv(msg.num)) await registrar(msg.num, 'NÃO INICIOU: ' + msg.erro); return { ok: true };
      case 'vincular': return vincular(String(msg.num), String(msg.com), !!msg.ligar);
      case 'parar': return parar(msg.num, 'Parado por você.');
      case 'pararTodos': {
        for (const e of (await todosEnvios()).filter(x => x.ativo)) await parar(e.num, 'Parado por você (parar todos).');
        return { ok: true };
      }
      case 'testar': rodar(msg.num, true, 0); return { ok: true };
      case 'testarSom': await tocar(msg.som || 'sucesso', true); return { ok: true };
      case 'lidas': await marcarLidas(msg.ids || null); await atualizarGeral(); return { ok: true };
      case 'limparNotifs': await escrever(() => chrome.storage.local.set({ notifs: [] })); await atualizarGeral(); return { ok: true };
      case 'centro': await salvarCentroManual(msg.cod, msg.nome); return { ok: true };
      case 'pedirCodigo': return chamarAPI('pedir_codigo', { email: String(msg.email || '').trim().toLowerCase() });
      case 'entrar': return entrar(msg.email, msg.codigo);
      case 'sair': return sair();
      case 'conferirConta': { const ok = await contaOk(true); return { ok, semAssinatura: !!(await lerConta() || {}).semAssinatura }; }
      case 'aceitarTermo': {
        if (msg.versao !== TERMO_VERSAO) return { ok: false, erro: 'Versão do termo desatualizada.' };
        await escrever(() => chrome.storage.local.set({ termo: { versao: TERMO_VERSAO, ts: Date.now(), extVersao: chrome.runtime.getManifest().version } }));
        await atualizarGeral();
        return { ok: true };
      }
      case 'abrirML': {
        await chrome.tabs.create({ url: linkHub(msg.num) });
        return { ok: true };
      }
    }
    return { ok: false };
  })().then(r => responder(r || { ok: true }), err => responder({ ok: false, erro: msgErro(err) }));
  return true;
});

chrome.alarms.onAlarm.addListener(a => { if (a.name === 'tick') tick(); });

// Clicar na notificação do Windows abre o popup (quando o Chrome permite).
chrome.notifications.onClicked.addListener(async id => {
  chrome.notifications.clear(id);
  try { await chrome.action.openPopup(); } catch (err) { /* versão do Chrome não permite */ }
});

async function arrumarAoIniciar(navegadorReiniciou) {
  await chrome.alarms.clear('ciclo');
  await chrome.storage.local.remove(['cfg', 'estado', 'logs']);
  if (navegadorReiniciou) await salvarGlob({ janelaId: null });
  for (const e of await todosEnvios()) {
    const patch = { proxima: 0, cfg: migrarCfg(e.cfg) };
    if (e.fase === 'marcando' || e.fase === 'testando') patch.fase = e.ativo ? 'monitorando' : 'parado';
    if (navegadorReiniciou) patch.tabId = null;
    await salvarEnv(e.num, patch);
  }
  await atualizarGeral();
}

chrome.runtime.onInstalled.addListener(() => arrumarAoIniciar(false));
chrome.runtime.onStartup.addListener(() => arrumarAoIniciar(true));
