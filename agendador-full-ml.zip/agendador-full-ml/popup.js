// ================= constantes =================
const CENTROS_PADRAO = [
  { cod: 'BRRC01', nome: 'Perus' },
  { cod: 'BRRC02', nome: 'Sumaré' },
  { cod: 'BRRC03', nome: 'Embu das Artes' },
  { cod: 'BRRC05', nome: 'Itupeva' }
];
const FORMAS = [
  { nome: 'Veículo particular', ic: 'carro', sub: 'você leva com o seu veículo', testado: true },
  { nome: 'Transportadora privada', ic: 'caminhao', sub: 'uma transportadora contratada leva', aviso: 'Ainda não testado: depois da data, o ML pode pedir dados extras (transportadora, placa) que a extensão não preenche. Acompanhe a primeira vez.' },
  { nome: 'Envio pelo fornecedor', ic: 'fabrica', sub: 'o fornecedor entrega direto', aviso: 'Ainda não testado: o ML pode pedir dados do fornecedor depois da data. Acompanhe a primeira vez.' },
  { nome: 'Coleta a domicílio', ic: 'casa', sub: 'o ML busca no seu endereço', aviso: 'O ML só libera em alguns envios. Se estiver indisponível, a extensão passa para a próxima opção.' }
];
const FAIXAS = [
  { id: 'mad', nome: 'Madrugada', ini: 0, fim: 5, aviso: 'entrega de madrugada' },
  { id: 'man', nome: 'Manhã', ini: 6, fim: 11 },
  { id: 'tar', nome: 'Tarde', ini: 12, fim: 17 },
  { id: 'noi', nome: 'Noite', ini: 18, fim: 23, aviso: 'entrega à noite' }
];
const MAX_OPCOES = 3;
const PASSOS = ['forma', 'centros', 'datas', 'horas'];
const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
const SEMANA = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];
const STATUS = { trava_fora: 'nenhuma opção aceita o centro/dia do grupo', indisp: 'sem vaga', disp: 'vaga encontrada', cd_nao_aceito: 'centro fora da lista', erro: 'erro (segue tentando)', deslogado: 'deslogado' };
// Ícones: sprite SVG no popup.html (estilo Lucide); svg('nome') devolve o <svg> pronto.
const svg = (n, c = 'ic') => `<svg class="${c}"><use href="#i-${n}"/></svg>`;
const ICONE_NOTIF = { sucesso: 'circ-check', reetiq: 'etiqueta', seguranca: 'alerta', deslogado: 'cadeado', falha: 'circ-x', prazo: 'relogio' };
const icNotif = (tipo, c) => svg(ICONE_NOTIF[tipo] || 'sino', c);
const GLOB_PADRAO = { intervalo: 60, ate: '', som: true };
const DIAS_QUALQUER = 60;
// Termo de uso: mudou o texto → sobe a versão e todos aceitam de novo (igual no background e no site/index.html).
const SITE = 'https://jonathannegrine-alt.github.io/agendador-full/';
const TERMO_VERSAO = 2;
const TERMO = [
  ['Uso por sua conta e risco.', 'Toda a configuração (forma de envio, centros, dias e horários) é feita por você. A extensão apenas segue o que você configurou.'],
  ['Ela marca sozinha.', 'Sem pedir confirmação na hora, marca o primeiro horário que encaixar na sua configuração. Em envio já agendado, pode trocar a reserva existente.'],
  ['Pode falhar.', 'O Mercado Livre pode mudar a página a qualquer momento, e a extensão pode não marcar, marcar um horário diferente do esperado ou parar de funcionar.'],
  ['Sem responsabilidade por prejuízos.', 'Não nos responsabilizamos por agendamentos errados, indesejados ou perdidos, troca de reserva ou de centro, reetiquetagem, atrasos, multas, cobranças, custos de transporte ou armazenagem, bloqueio ou suspensão da conta, nem por qualquer outro prejuízo, direto ou indireto, decorrente do uso.'],
  ['Regras do Mercado Livre.', 'O uso de automação pode não ser permitido pelos termos do Mercado Livre. Esse risco é seu.'],
  ['Confira sempre.', 'Confira no Mercado Livre a data, o horário e o centro de cada envio. A responsabilidade pelo envio e pelas regras do Full é sua.'],
  ['Seus dados.', 'Envios, configurações e histórico ficam só neste Chrome. No nosso servidor ficam apenas nome, e-mail, aceite do termo e dados de acesso (veja a política de privacidade no site).']
];

// ================= utilidades =================
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = n => String(n).padStart(2, '0');
const fmtData = d => `${pad(d.d)}/${pad(d.m)}`;
const valorData = d => new Date(d.y, d.m - 1, d.d).getTime();
const hojeZero = () => { const h = new Date(); h.setHours(0, 0, 0, 0); return h; };
const somarDias = (dt, n) => { const x = new Date(dt); x.setDate(x.getDate() + n); return x; };
const paraObj = dt => ({ y: dt.getFullYear(), m: dt.getMonth() + 1, d: dt.getDate() });
// Sem resposta do background (ex.: "message port closed"): devolve o motivo em vez de {} mudo.
const enviar = msg => new Promise(r => chrome.runtime.sendMessage(msg, resp => {
  const le = chrome.runtime.lastError;
  if (le) return r({ ok: false, semResposta: true, erro: 'a extensão não respondeu (' + (le.message || 'sem detalhe') + ')' });
  r(resp || { ok: false, semResposta: true, erro: 'a extensão respondeu vazio' });
}));
const clonar = o => JSON.parse(JSON.stringify(o));
const tituloLimpo = t => String(t || '').replace(/^[^\p{L}\p{N}#]+/u, '');
const quando = ts => {
  const d = new Date(ts), h = new Date();
  const hora = d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  return d.toDateString() === h.toDateString() ? `hoje, ${hora}` : `${pad(d.getDate())}/${pad(d.getMonth() + 1)}, ${hora}`;
};

// ================= estado =================
const S = {
  glob: { ...GLOB_PADRAO }, lista: [], envs: {}, logs: {}, notifs: [], centrosML: {},
  numAba: null, urlAba: '',
  tela: 'lista', num: null, op: 0, passo: 1, notifId: null,
  ed: null, cal: null, sit: null, sitCarregando: false, iniciando: false, apertado: false, erroIniciar: '', apertouIniciar: false, cliqueIniciar: false, autoCancelado: false, modalAgendado: false,
  erroAdd: '', logAberto: false, mostrarGrade: false, pendente: false,
  termo: null, termoMarcado: false,
  conta: null, login: { email: '', etapa: 'email', msg: '', tipoMsg: '', ocupado: false }
};
const logado = () => !!S.conta && !!S.conta.token;
const aceitou = () => !!S.termo && S.termo.versao === TERMO_VERSAO;

async function carregar() {
  const all = await chrome.storage.local.get(null);
  S.glob = { ...GLOB_PADRAO, ...(all.glob || {}) };
  S.lista = all.lista || [];
  S.notifs = all.notifs || [];
  S.centrosML = all.centros || {};
  S.termo = all.termo || null;
  S.conta = all.conta || null;
  S.envs = {}; S.logs = {};
  for (const n of S.lista) { S.envs[n] = all['env_' + n]; S.logs[n] = all['log_' + n] || []; }
}

let timerSalvar = null;
function salvarCfg() {
  clearTimeout(timerSalvar);
  const num = S.num, cfg = clonar(S.ed);
  timerSalvar = setTimeout(() => enviar({ tipo: 'cfg', num, cfg }), 250);
}
async function salvarCfgAgora() {
  clearTimeout(timerSalvar);
  await enviar({ tipo: 'cfg', num: S.num, cfg: clonar(S.ed) });
}

// ================= configuração (opções) =================
function opcaoPadrao() {
  return { tipoEnvio: '', cds: [], datasModo: '', datas: [], datasN: 7, datasAte: null, horas: {} };
}
// Mesma conversão do background: config antiga (verde/amarelo) vira opções.
function migrar(c) {
  if (!c) return { opcoes: [] };
  if (Array.isArray(c.opcoes)) return { opcoes: c.opcoes.slice(0, MAX_OPCOES).map(o => ({ ...opcaoPadrao(), ...o })) };
  const base = {
    ...opcaoPadrao(), tipoEnvio: c.tipoEnvio || 'Veículo particular', cds: c.cds || [],
    datasModo: c.datasModo || ((c.datas || []).length ? 'lista' : ''), datas: c.datas || [], datasN: c.datasN || 7, datasAte: c.datasAte || null
  };
  const pref = {}, aceito = {};
  for (const [h, v] of Object.entries(c.horas || {})) (v === 2 ? aceito : pref)[h] = 1;
  if (!Object.keys(pref).length && !Object.keys(aceito).length && !base.cds.length && !base.datasModo) return { opcoes: [] };
  const opcoes = [{ ...base, horas: Object.keys(pref).length ? pref : aceito }];
  if (Object.keys(pref).length && Object.keys(aceito).length) opcoes.push({ ...clonar(base), horas: aceito });
  return { opcoes };
}
const opAtual = () => S.ed.opcoes[S.op];

function todosCentros() {
  const mapa = new Map();
  for (const c of CENTROS_PADRAO) mapa.set(c.cod, { ...c, ml: false });
  for (const [cod, v] of Object.entries(S.centrosML)) {
    if (mapa.has(cod)) mapa.get(cod).ml = true;
    else mapa.set(cod, { cod, nome: v.nome || cod, ml: !v.manual, manual: !!v.manual });
  }
  return [...mapa.values()].sort((a, b) => a.cod.localeCompare(b.cod));
}
function nomeCentro(cod) {
  const c = todosCentros().find(x => x.cod === cod);
  return c ? `${c.nome} (${cod})` : cod;
}
const horasSel = o => Object.keys(o.horas || {}).map(Number).sort((a, b) => a - b);
function faixasDe(hs) {
  const out = [];
  let ini = null, ant = null;
  for (const h of hs) {
    if (ini === null) { ini = ant = h; continue; }
    if (h === ant + 1) { ant = h; continue; }
    out.push([ini, ant]); ini = ant = h;
  }
  if (ini !== null) out.push([ini, ant]);
  return out;
}
const txtFaixa = ([a, b]) => a === b ? `${pad(a)}h` : `${pad(a)}–${pad(b)}h`;
const txtHoras = hs => faixasDe(hs).map(txtFaixa).join(', ');

function datasFuturas(o) {
  const h = hojeZero().getTime();
  return (o.datas || []).filter(d => valorData(d) >= h).sort((a, b) => valorData(a) - valorData(b));
}
function datasOk(o) {
  if (o.datasModo === 'lista') return datasFuturas(o).length > 0;
  if (o.datasModo === 'ate') return !!o.datasAte && valorData(o.datasAte) >= hojeZero().getTime();
  return o.datasModo === 'qualquer' || o.datasModo === 'proximos';
}
function pendOpcao(o) {
  const p = [];
  if (!o.tipoEnvio) p.push('forma de envio');
  if (!(o.cds || []).length) p.push('centro');
  if (!datasOk(o)) p.push('dias');
  if (!horasSel(o).length) p.push('horários');
  return p;
}
function pendencias(cfg) {
  if (!cfg.opcoes.length) return ['pelo menos 1 opção'];
  const p = [];
  cfg.opcoes.forEach((o, i) => { const x = pendOpcao(o); if (x.length) p.push(`opção ${i + 1}: ${x.join(', ')}`); });
  return p;
}

function txtDatas(o, curto) {
  const h = hojeZero();
  if (o.datasModo === 'lista') {
    const ds = datasFuturas(o);
    if (!ds.length) return 'nenhum dia escolhido';
    const lista = curto && ds.length > 4 ? ds.slice(0, 4).map(fmtData).join(', ') + ` +${ds.length - 4}` : ds.map(fmtData).join(', ');
    return ds.length === 1 ? `só ${lista}` : `${lista}${curto ? '' : ' — o mais cedo primeiro'}`;
  }
  if (o.datasModo === 'proximos') {
    const fim = paraObj(somarDias(h, (o.datasN || 7) - 1));
    return `qualquer dia liberado nos próximos ${o.datasN} dias (até ${fmtData(fim)})${curto ? '' : ' — o mais cedo primeiro'}`;
  }
  if (o.datasModo === 'ate') return o.datasAte ? `qualquer dia liberado até ${fmtData(o.datasAte)}${curto ? '' : ' — o mais cedo primeiro'}` : 'até o dia —';
  if (o.datasModo === 'qualquer') return `qualquer dia liberado${curto ? '' : ` (até ${DIAS_QUALQUER} dias à frente) — o mais cedo primeiro`}`;
  return 'dias não escolhidos';
}
function txtHorarios(o) {
  const hs = horasSel(o);
  if (!hs.length) return 'horários não escolhidos';
  if (hs.length === 24) return 'qualquer horário';
  return `entre ${txtHoras(hs)}`;
}
const txtCentros = o => (o.cds || []).length ? o.cds.map((x, i) => `${o.cds.length > 1 ? (i + 1) + 'º ' : ''}${nomeCentro(x)}`).join(' · ') : 'centro não escolhido';
function avisosOpcao(o) {
  const a = [];
  const hs = horasSel(o);
  const f = FORMAS.find(x => x.nome === o.tipoEnvio);
  if (f && f.aviso) a.push(`${o.tipoEnvio}: ${f.aviso}`);
  if (o.datasModo === 'qualquer') a.push(`Qualquer dia: pode marcar uma data distante (até ${DIAS_QUALQUER} dias à frente).`);
  if (hs.length === 24) a.push('Qualquer horário: pode marcar de madrugada ou à noite.');
  else {
    if (hs.some(h => h <= 5)) a.push('Inclui horários de madrugada (00h–05h).');
    if (hs.some(h => h >= 18)) a.push('Inclui horários à noite (18h–23h).');
  }
  if ((o.cds || []).length > 1) a.push('Mais de um centro: se marcar num centro diferente do atual do envio, você terá que reetiquetar todos os volumes.');
  return a;
}
function avisosGerais(cfg) {
  const a = [];
  const cds = new Set(cfg.opcoes.flatMap(o => o.cds || []));
  if (cfg.opcoes.length > 1 && cds.size > 1 && !cfg.opcoes.some(o => o.cds.length > 1)) a.push('As opções usam centros diferentes: se marcar num centro diferente do atual do envio, você terá que reetiquetar todos os volumes.');
  return a;
}
function linhasOpcao(o) {
  return [
    { ic: 'caminhao', rot: 'Forma de envio', txt: o.tipoEnvio || 'não escolhida' },
    { ic: 'pin', rot: o.cds.length > 1 ? 'Centros, em ordem' : 'Centro', txt: txtCentros(o) },
    { ic: 'cal', rot: 'Dias', txt: txtDatas(o, false) },
    { ic: 'relogio', rot: 'Horários', txt: txtHorarios(o) }
  ];
}
const htmlLinhas = ls => `<div class="resumo-lista">${ls.map(l => `<div class="rl"><span>${svg(l.ic)}</span><div><small>${esc(l.rot)}</small>${esc(l.txt)}</div></div>`).join('')}</div>`;
const htmlAvisos = a => a.length ? `<div class="avisos">${a.map(x => `<div><svg class="ic-sm"><use href="#i-alerta"/></svg> ${esc(x)}</div>`).join('')}</div>` : '';

// ================= peças visuais =================
function pill(e) {
  if (e.fase === 'agendado') return '<span class="pill ok"><svg class="ic-xs"><use href="#i-check"/></svg>Agendado</span>';
  if (e.fase === 'marcando') return '<span class="pill raio"><svg class="ic-xs"><use href="#i-raio"/></svg>Marcando…</span>';
  if (e.fase === 'testando') return '<span class="pill info"><svg class="ic-xs"><use href="#i-ampulheta"/></svg>Testando…</span>';
  if (e.fase === 'deslogado') return '<span class="pill erro"><svg class="ic-xs"><use href="#i-cadeado"/></svg>Deslogado</span>';
  if (e.ativo) return '<span class="pill on"><i class="ponto"></i>Monitorando</span>';
  return '<span class="pill off">Parado</span>';
}
function meta(e) {
  if (e.fase === 'deslogado') return 'O Mercado Livre deslogou. Entre de novo e clique em Iniciar.';
  const p = [];
  if (e.ultima) p.push(`Última checagem ${new Date(e.ultima).toLocaleTimeString('pt-BR')} · ${STATUS[e.ultimoStatus] || '—'}`);
  if ((e.erros || 0) >= 3) p.push(`${e.erros} erros seguidos, segue tentando`);
  return p.join(' · ') || 'Ainda não checado';
}
function resumoCurto(cfg) {
  if (!cfg.opcoes.length) return '<span class="vazio-cfg">Ainda não configurado</span>';
  return cfg.opcoes.map((o, i) =>
    `<div class="rc-op"><b>${i + 1}</b><span>${esc(o.tipoEnvio || '—')} · ${esc((o.cds || []).map(c => nomeCentro(c)).join(', ') || '—')}<br><svg class="ic-xs"><use href="#i-cal"/></svg> ${esc(txtDatas(o, true))} · <svg class="ic-xs"><use href="#i-relogio"/></svg> ${esc(txtHorarios(o))}</span></div>`).join('');
}
function blocoResultado(e) {
  const r = e.resultado;
  if (!r) return '';
  return `${r.reetiq ? `<div class="banner alerta"><b><svg class="ic-sm"><use href="#i-alerta"/></svg> PRECISA REETIQUETAR OS VOLUMES</b><div class="banner-meta">O centro mudou: as etiquetas atuais não valem mais. Informe as caixas, baixe as etiquetas novas e cole em todos os volumes.</div></div>` : ''}
    <div class="banner ok"><b><svg class="ic-sm"><use href="#i-circ-check"/></svg> Agendado: ${esc(r.quando || r.resumo)}</b>
      ${r.centro ? `<div class="banner-meta"><svg class="ic-sm"><use href="#i-pin"/></svg> ${esc(r.centro)}</div>` : ''}
      ${r.prazo ? `<div class="banner-meta"><svg class="ic-sm"><use href="#i-lapis"/></svg> ${esc(r.prazo)}</div>` : ''}
      <div class="banner-meta">Próximos passos: revisar a preparação, etiquetar os volumes, emitir a NF-e e baixar a autorização de entrada. Chegue no horário: o ML recusa atrasos.</div>
      <button class="btn mini" data-acao="abrirML" data-num="${esc(e.num)}">Abrir o envio no ML <svg class="ic-xs"><use href="#i-externo"/></svg></button>
    </div>`;
}
const naoLidas = () => S.notifs.filter(n => !n.lida);

// ================= envios vinculados =================
const parceiros = n => { const g = S.envs[n] && S.envs[n].grupo; return g ? S.lista.filter(x => x !== n && S.envs[x] && S.envs[x].grupo === g) : []; };
const txtTrava = t => `${t.nome} (${t.cd}) no dia ${pad(t.data.d)}/${pad(t.data.m)}`;
// A opção aceita o centro e o dia travados? (mesma regra do background)
function aceitaTrava(o, t) {
  if (!(o.cds || []).some(c => c.toUpperCase() === t.cd)) return false;
  const v = new Date(t.data.y, t.data.m - 1, t.data.d).getTime();
  const hoje = new Date(); hoje.setHours(0, 0, 0, 0);
  const mais = n => { const x = new Date(hoje); x.setDate(x.getDate() + n); return x.getTime(); };
  if (!o.datasModo || o.datasModo === 'lista') return (o.datas || []).some(d => d.y === t.data.y && d.m === t.data.m && d.d === t.data.d);
  if (v < hoje.getTime()) return false;
  if (o.datasModo === 'proximos') return v <= mais(Math.max(1, o.datasN || 7) - 1);
  if (o.datasModo === 'ate' && o.datasAte) return v <= new Date(o.datasAte.y, o.datasAte.m - 1, o.datasAte.d).getTime();
  return v <= mais(60);
}
function bannerTrava(e, cfg) {
  const ps = parceiros(e.num);
  if (!ps.length) return '';
  const t = e.trava;
  if (!t) return `<div class="banner info">${svg('corrente', 'ic-sm')} Vinculado a ${ps.map(p => '#' + esc(p)).join(', ')}: o primeiro que marcar define o centro e o dia dos outros.</div>`;
  const algum = cfg.opcoes.some(o => aceitaTrava(o, t));
  return `<div class="banner ${algum ? 'info' : 'alerta'}">${svg('corrente', 'ic-sm')} Só <b>${esc(txtTrava(t))}</b>: o #${esc(t.de)} está agendado lá.
    ${algum ? '' : '<div class="banner-meta"><b>Nenhuma opção deste envio aceita esse centro e esse dia.</b> Ajuste as opções ou desvincule, senão ele não vai achar vaga.</div>'}</div>`;
}
function blocoVinculo(e, outros, travado) {
  const g = e.grupo;
  const chips = outros.map(o => {
    const sel = g && S.envs[o].grupo === g;
    return `<button class="chip ${sel ? 'sel' : ''}" data-vinc="${esc(o)}" ${travado ? 'disabled' : ''}>${sel ? svg('corrente', 'ic-xs') : ''}#${esc(o)}${S.envs[o].fase === 'agendado' ? ' <small>agendado</small>' : ''}</button>`;
  }).join('');
  return `<div class="secao-titulo">Mesmo centro e dia que</div>
    <p class="dica">Para envios que vão juntos (mesmo caminhão): o primeiro que marcar define o centro e o dia, e os outros só aceitam esse centro e esse dia, nos horários de cada um.</p>
    <div class="chips vinc">${chips}</div>
    ${bannerTrava(e, S.ed)}`;
}

// ================= tela: lista =================
function telaLista() {
  const alerta = naoLidas()[0];
  const ativos = S.lista.filter(n => S.envs[n] && S.envs[n].ativo);
  const cards = S.lista.map(n => {
    const e = S.envs[n];
    if (!e) return '';
    const r = e.resultado;
    return `<div class="card" data-abrir="${esc(n)}" role="button" tabindex="0">
      <div class="card-linha"><span class="card-num">Envio <b>#${esc(n)}</b>${parceiros(n).length ? `<span class="vinc-ic" title="Vinculado a ${esc(parceiros(n).map(p => '#' + p).join(', '))}">${svg('corrente', 'ic-xs')}</span>` : ''}<span class="seta"><svg class="ic-sm"><use href="#i-dir"/></svg></span></span>${pill(e)}</div>
      ${e.ativo ? `<div class="card-parar"><span class="card-meta">${esc(meta(e))}</span><button class="btn perigo mini" data-parar="${esc(n)}"><svg class="ic-xs cheio"><use href="#i-stop"/></svg> Parar</button></div>` : ''}
      <div class="card-resumo">${resumoCurto(migrar(e.cfg))}</div>
      ${r ? `<div class="resultado-card ${r.reetiq ? 'alerta' : ''}">${r.reetiq ? '<svg class="ic-sm"><use href="#i-alerta"/></svg> Reetiquetar · ' : '<svg class="ic-sm"><use href="#i-circ-check"/></svg> '}${esc(r.resumo)}</div>` : (!e.ativo ? `<div class="card-meta">${esc(meta(e))}</div>` : '')}
    </div>`;
  }).join('');

  const podeAdd = S.lista.length < 3;
  const sugerir = podeAdd && S.numAba && !S.lista.includes(S.numAba);
  const opcoesInt = [30, 45, 60, 90, 120].map(s => `<option value="${s}" ${+S.glob.intervalo === s ? 'selected' : ''}>${s} s</option>`).join('');

  return `
    ${alerta ? `<button class="faixa-alerta tipo-${esc(alerta.tipo)}" data-notif="${esc(alerta.id)}">
        <span class="fa-ic">${icNotif(alerta.tipo)}</span>
        <span class="fa-txt"><b>${esc(tituloLimpo(alerta.titulo))}</b><small>${esc(quando(alerta.ts))} · toque para ver${naoLidas().length > 1 ? ` · +${naoLidas().length - 1} não lida(s)` : ''}</small></span>
        <span class="seta"><svg class="ic-sm"><use href="#i-dir"/></svg></span></button>` : ''}
    ${S.lista.length ? `<div class="secao-titulo">Seus envios <span class="cont">${S.lista.length}/3</span>
        ${ativos.length >= 2 ? '<button class="btn perigo mini" data-acao="pararTodos"><svg class="ic-xs cheio"><use href="#i-stop"/></svg> Parar todos</button>' : ''}</div>${cards}` : `
      <div class="vazio"><div class="ilustra"><svg class="ic-lg"><use href="#i-caixa"/></svg></div><b>Nenhum envio ainda</b>
      <p>Abra o envio no Mercado Livre (preparação ou agendamento) e adicione aqui, ou digite o número.</p></div>`}
    ${podeAdd ? `
      <div class="add">
        ${sugerir ? `<button class="btn primario largo" data-acao="addAba"><svg class="ic-sm"><use href="#i-mais"/></svg> Adicionar envio #${esc(S.numAba)} <small>(desta aba)</small></button>` : ''}
        <div class="add-manual">
          <input id="inNum" inputmode="numeric" placeholder="${sugerir ? 'Ou digite outro nº de envio' : 'Nº do envio'}" maxlength="15">
          <button class="btn" data-acao="addManual">Adicionar</button>
        </div>
        ${S.erroAdd ? `<div class="erro-msg">${esc(S.erroAdd)}</div>` : ''}
      </div>` : `<div class="aviso-limite">Limite de <b>3 envios</b> ao mesmo tempo. Remova um para adicionar outro.</div>`}
    <div class="globais">
      <label>Checar a cada<select id="selInt">${opcoesInt}</select></label>
      <label>Parar às <small>(opcional)</small><input type="datetime-local" id="inAte" value="${esc(S.glob.ate || '')}"></label>
      <p class="nota">Recarrega sem limite: só para quando marcar, se o ML deslogar ou no horário de "Parar às".</p>
    </div>
    <div class="conta-rodape"><svg class="ic-xs"><use href="#i-usuario"/></svg> ${esc(S.conta.email)} · <button class="link-inline" data-acao="sair">Sair</button></div>
    <button class="link" data-acao="termo">Termo de uso e responsabilidade</button>`;
}

// ================= tela: notificações =================
function telaNotifs() {
  const itens = S.notifs.map(n => `
    <button class="notif ${n.lida ? '' : 'nova'}" data-notif="${esc(n.id)}">
      <span class="n-ic">${icNotif(n.tipo)}</span>
      <span class="n-txt"><b>${esc(tituloLimpo(n.titulo))}</b><small>${esc(quando(n.ts))}</small></span>
      ${n.lida ? '' : '<i class="n-ponto"></i>'}
    </button>`).join('');
  return `
    <div class="ed-topo"><button class="voltar" data-acao="inicio"><svg class="ic"><use href="#i-esq"/></svg></button><div class="ed-tit"><span class="ed-num">Notificações</span>
      ${naoLidas().length ? '<button class="btn mini" data-acao="todasLidas">Marcar todas como lidas</button>' : ''}</div></div>
    <div class="bloco som">
      <div><b>Som de alerta</b><small>Toca quando marca, falha ou o ML desloga.</small></div>
      <div class="som-acoes">
        <button class="btn mini" data-acao="testarSom"><svg class="ic-xs cheio"><use href="#i-play"/></svg> Testar</button>
        <button class="toggle ${S.glob.som ? 'on' : ''}" data-acao="som" aria-label="Som de alerta"><i></i></button>
      </div>
    </div>
    ${S.notifs.length ? `<div class="lista-notifs">${itens}</div><button class="link" data-acao="limparNotifs">Limpar histórico de notificações</button>`
      : '<div class="vazio"><div class="ilustra"><svg class="ic-lg"><use href="#i-sino-off"/></svg></div><b>Nenhuma notificação</b><p>Quando a extensão marcar, falhar ou precisar de você, o aviso aparece aqui.</p></div>'}`;
}

function telaNotif() {
  const n = S.notifs.find(x => x.id === S.notifId);
  if (!n) { S.tela = 'notifs'; return telaNotifs(); }
  const temEnvio = n.num && S.envs[n.num];
  return `
    <div class="ed-topo"><button class="voltar" data-acao="notifs"><svg class="ic"><use href="#i-esq"/></svg></button><div class="ed-tit"><span class="ed-num">Notificação</span></div></div>
    <div class="bloco det tipo-${esc(n.tipo)}">
      <div class="det-ic">${icNotif(n.tipo)}</div>
      <h2>${esc(tituloLimpo(n.titulo))}</h2>
      <p class="det-meta">${esc(new Date(n.ts).toLocaleString('pt-BR'))}${n.num ? ` · Envio #${esc(n.num)}` : ''}</p>
      <div class="det-msg">${esc(n.msg)}</div>
    </div>
    <div class="acoes ${temEnvio ? '' : 'um'}">
      ${n.num ? `<button class="btn primario" data-acao="abrirML" data-num="${esc(n.num)}">Abrir o envio no ML <svg class="ic-xs"><use href="#i-externo"/></svg></button>` : ''}
      ${temEnvio ? `<button class="btn" data-abrir="${esc(n.num)}">Ver na extensão</button>` : ''}
    </div>`;
}

// ================= tela: envio =================
function telaEnvio() {
  const n = S.num, e = S.envs[n];
  const cfg = S.ed;
  const pend = pendencias(cfg);
  const outros = S.lista.filter(x => x !== n && S.envs[x]);
  const log = (S.logs[n] || []).join('\n') || 'Sem registros ainda.';
  const travado = e.ativo || e.fase === 'testando' || e.fase === 'marcando';

  const ops = cfg.opcoes.map((o, i) => {
    const p = pendOpcao(o);
    return `<div class="op-card ${p.length ? 'incompleta' : ''}">
      <div class="op-topo">
        <span class="op-num">Opção ${i + 1}</span>
        ${i === 0 ? '<span class="op-tag">tenta primeiro</span>' : ''}
        ${!travado ? `<span class="op-acoes">
          <button class="mini-ic" data-opmover="${i}" data-dir="-1" ${i === 0 ? 'disabled' : ''} title="Subir"><svg class="ic-sm"><use href="#i-cima"/></svg></button>
          <button class="mini-ic" data-opmover="${i}" data-dir="1" ${i === cfg.opcoes.length - 1 ? 'disabled' : ''} title="Descer"><svg class="ic-sm"><use href="#i-baixo"/></svg></button>
          <button class="mini-ic" data-opapagar="${i}" title="Apagar">×</button>
        </span>` : ''}
      </div>
      ${htmlLinhas(linhasOpcao(o))}
      ${p.length ? `<div class="falta esq">Falta: ${esc(p.join(', '))}</div>` : ''}
      ${!travado ? `<button class="btn mini largo" data-opeditar="${i}"><svg class="ic-sm"><use href="#i-lapis"/></svg> Editar opção ${i + 1}</button>` : ''}
    </div>`;
  }).join('');

  let acoes;
  if (e.ativo) acoes = '<div class="acoes um"><button class="btn perigo largo" data-acao="parar"><svg class="ic-xs cheio"><use href="#i-stop"/></svg> Parar monitoramento</button></div>';
  else if (e.fase === 'testando') acoes = '<div class="acoes um"><button class="btn largo" disabled><svg class="ic-sm"><use href="#i-ampulheta"/></svg> Testando, aguarde…</button></div>';
  else acoes = `<div class="acoes">
      <button class="btn" data-acao="testar" ${pend.length ? 'disabled' : ''} title="Faz uma checagem sem marcar nada">Testar</button>
      <button class="btn sucesso" data-acao="revisar" ${pend.length ? 'disabled' : ''}><svg class="ic-xs cheio"><use href="#i-play"/></svg> Revisar e iniciar</button>
    </div>${pend.length && cfg.opcoes.length ? `<div class="falta">Falta completar: ${esc(pend.join(' · '))}</div>` : ''}`;

  return `
    <div class="ed-topo">
      <button class="voltar" data-acao="inicio"><svg class="ic"><use href="#i-esq"/></svg></button>
      <div class="ed-tit"><span class="ed-num">Envio <b>#${esc(n)}</b></span>${pill(e)}</div>
    </div>
    ${blocoResultado(e)}
    ${e.fase === 'deslogado' ? '<div class="banner alerta"><b><svg class="ic-sm"><use href="#i-cadeado"/></svg> O Mercado Livre deslogou</b><div class="banner-meta">Entre de novo no ML neste Chrome e clique em "Revisar e iniciar".</div></div>' : ''}
    ${e.ativo ? `<div class="banner on"><b>Monitorando.</b> Para mudar as opções, pare primeiro.<div class="banner-meta">${esc(meta(e))}</div></div>` : ''}
    <div class="secao-titulo">Opções de agendamento <span class="cont">${cfg.opcoes.length}/${MAX_OPCOES}</span></div>
    ${cfg.opcoes.length ? `<p class="dica">A extensão tenta a <b>Opção 1</b>. Se não houver vaga nela, tenta a 2, depois a 3. A primeira que encaixar é marcada.</p>${ops}` : `
      <div class="vazio"><div class="ilustra"><svg class="ic-lg"><use href="#i-cal"/></svg></div><b>Nenhuma opção ainda</b><p>Crie a Opção 1: forma de envio, centro, dias e horários.</p></div>`}
    ${!travado && cfg.opcoes.length < MAX_OPCOES ? `<button class="btn ${cfg.opcoes.length ? '' : 'primario'} largo add-op" data-acao="novaOpcao"><svg class="ic-sm"><use href="#i-mais"/></svg> ${cfg.opcoes.length ? `Adicionar opção ${cfg.opcoes.length + 1}` : 'Criar a Opção 1'}</button>` : ''}
    ${!travado && cfg.opcoes.length ? `<div class="sub-acoes solta">
        <button class="link-inline" data-acao="duplicar" ${cfg.opcoes.length >= MAX_OPCOES ? 'disabled' : ''}><svg class="ic-xs"><use href="#i-copiar"/></svg> Duplicar a última opção</button>
        ${outros.length ? `<select id="selCopiar"><option value="">Copiar de outro envio…</option>${outros.map(o => `<option value="${esc(o)}">#${esc(o)}</option>`).join('')}</select>` : ''}
      </div>` : (!travado && outros.length ? `<div class="sub-acoes solta"><span></span><select id="selCopiar"><option value="">Copiar de outro envio…</option>${outros.map(o => `<option value="${esc(o)}">#${esc(o)}</option>`).join('')}</select></div>` : '')}
    ${outros.length ? blocoVinculo(e, outros, travado) : ''}
    ${acoes}
    <details class="log" ${S.logAberto ? 'open' : ''}><summary>Histórico deste envio</summary><pre>${esc(log)}</pre></details>
    ${!travado ? '<button class="link perigo" data-acao="remover">Remover este envio</button>' : ''}`;
}

// ================= editor de opção =================
function telaOpcao() {
  const o = opAtual();
  if (!o) return telaEnvio();
  const atual = PASSOS[S.passo - 1];
  const corpo = { forma: edForma, centros: edCentros, datas: edDatas, horas: edHoras }[atual](o);
  const ok = { forma: !!o.tipoEnvio, centros: o.cds.length > 0, datas: datasOk(o), horas: horasSel(o).length > 0 }[atual];
  const ultimo = S.passo === PASSOS.length;
  const feito = { forma: !!o.tipoEnvio, centros: o.cds.length > 0, datas: datasOk(o), horas: horasSel(o).length > 0 };
  const passos = PASSOS.map((p, i) => `<button class="pp ${i + 1 === S.passo ? 'at' : ''} ${feito[p] ? 'ok' : ''}" data-irpasso="${i + 1}">${feito[p] ? '<svg class="ic-xs"><use href="#i-check"/></svg>' : ''}${['Forma', 'Centros', 'Dias', 'Horários'][i]}</button>`).join('');
  return `
    <div class="ed-topo">
      <button class="voltar" data-acao="${S.passo > 1 ? 'edVoltar' : 'envio'}"><svg class="ic"><use href="#i-esq"/></svg></button>
      <div class="ed-tit"><span class="ed-num">Opção ${S.op + 1} · <b>#${esc(S.num)}</b></span><span class="passo-txt">Passo ${S.passo} de ${PASSOS.length}</span></div>
    </div>
    <div class="trilha">${passos}</div>
    ${corpo}
    <div class="acoes um">${ultimo
      ? `<button class="btn sucesso largo" data-acao="salvarOpcao" ${ok ? '' : 'disabled'}><svg class="ic-sm"><use href="#i-check"/></svg> Salvar opção ${S.op + 1}</button>`
      : `<button class="btn primario largo" data-acao="edAvancar" ${ok ? '' : 'disabled'}>Continuar <svg class="ic-sm"><use href="#i-dir"/></svg></button>`}</div>`;
}

function edForma(o) {
  return `<section class="bloco">
    <h2 class="pergunta-g">Como você vai enviar os produtos?</h2>
    <p class="dica">É a mesma escolha da página de agendamento do ML.</p>
    ${FORMAS.map(f => `
      <div class="opcao-l ${o.tipoEnvio === f.nome ? 'sel' : ''}">
        <button class="ol-cab" data-forma="${esc(f.nome)}"><i class="radio"></i><span class="ol-ic">${svg(f.ic)}</span><span><b>${esc(f.nome)} ${f.testado ? '<em class="selo"><svg class="ic-xs"><use href="#i-check"/></svg>testado</em>' : ''}</b><small>${esc(f.sub)}</small></span></button>
        ${f.aviso && o.tipoEnvio === f.nome ? `<div class="aviso-op"><svg class="ic-sm"><use href="#i-alerta"/></svg> ${esc(f.aviso)}</div>` : ''}
      </div>`).join('')}
  </section>`;
}

function edCentros(o) {
  const chips = todosCentros().map(x => {
    const i = o.cds.indexOf(x.cod);
    return `<button class="chip ${i >= 0 ? 'sel' : ''}" data-cd="${esc(x.cod)}">${i >= 0 ? `<span class="ord">${i + 1}º</span>` : ''}${esc(x.nome)} <b class="cod">${esc(x.cod)}</b>${x.ml ? '<small class="tag">visto no ML</small>' : ''}</button>`;
  }).join('');
  const sel = o.cds.map((cod, i) => `
    <div class="ordem-item"><span class="ord">${i + 1}º</span><span class="oi-nome">${esc(nomeCentro(cod))}</span>
      <button class="mini-ic" data-mover="${i}" data-dir="-1" ${i === 0 ? 'disabled' : ''} title="Subir"><svg class="ic-sm"><use href="#i-cima"/></svg></button>
      <button class="mini-ic" data-mover="${i}" data-dir="1" ${i === o.cds.length - 1 ? 'disabled' : ''} title="Descer"><svg class="ic-sm"><use href="#i-baixo"/></svg></button>
      <button class="mini-ic" data-cd="${esc(cod)}" title="Tirar">×</button></div>`).join('');
  return `<section class="bloco">
    <h2 class="pergunta-g">Para quais centros logísticos?</h2>
    <p class="dica">O código <b>BRRC</b> é o mesmo da etiqueta dos volumes. Nesta opção, a extensão <b>nunca</b> marca num centro que não esteja aqui.</p>
    <div class="chips">${chips}</div>
    <div class="linha-add"><input id="inCd" placeholder="Código (ex.: BRSP04)" maxlength="8"><input id="inCdNome" placeholder="Nome (opcional)" maxlength="30"><button class="btn mini" data-acao="addCd">Adicionar</button></div>
    ${o.cds.length > 1 ? `<div class="sub-t">Ordem dentro desta opção <small>(use as setas para mudar)</small></div><div class="ordem">${sel}</div>
      <div class="aviso-op"><svg class="ic-sm"><use href="#i-alerta"/></svg> Se a vaga sair num centro diferente do atual do envio, você terá que <b>reetiquetar todos os volumes</b>.</div>` : ''}
  </section>`;
}

function edDatas(o) {
  const h = hojeZero();
  const fimN = n => fmtData(paraObj(somarDias(h, n - 1)));
  const op = (modo, titulo, sub, extra, aviso) => `
    <div class="opcao-l ${o.datasModo === modo ? 'sel' : ''}">
      <button class="ol-cab" data-dmodo="${modo}"><i class="radio"></i><span><b>${titulo}</b>${sub ? `<small>${sub}</small>` : ''}</span></button>
      ${aviso ? `<div class="aviso-op"><svg class="ic-sm"><use href="#i-alerta"/></svg> ${aviso}</div>` : ''}
      ${o.datasModo === modo && extra ? `<div class="ol-extra">${extra}</div>` : ''}
    </div>`;
  const ns = [3, 7, 15].map(n => `<button class="seg ${o.datasN === n ? 'sel' : ''}" data-dn="${n}">${n} dias<small>até ${fimN(n)}</small></button>`).join('');
  const minimo = `${h.getFullYear()}-${pad(h.getMonth() + 1)}-${pad(h.getDate())}`;
  const valAte = o.datasAte ? `${o.datasAte.y}-${pad(o.datasAte.m)}-${pad(o.datasAte.d)}` : '';
  return `<section class="bloco">
    <h2 class="pergunta-g">Quais dias servem?</h2>
    <p class="dica">Entre os dias que servem, a extensão sempre tenta o <b>mais cedo</b> primeiro.</p>
    ${op('proximos', 'Os próximos dias', 'conta a partir de hoje e anda junto com o calendário', `<div class="segs">${ns}</div>`)}
    ${op('ate', 'Qualquer dia até uma data', '', `<input type="date" id="inDataAte" min="${minimo}" value="${valAte}">`)}
    ${op('lista', 'Escolher os dias no calendário', 'só os dias que você marcar', blocoCalendario(o))}
    ${op('qualquer', 'Qualquer dia disponível', `até ${DIAS_QUALQUER} dias à frente`, '', 'pode marcar uma data distante.')}
  </section>`;
}

function edHoras(o) {
  const sel = new Set(horasSel(o));
  const faixaOn = f => { for (let h = f.ini; h <= f.fim; h++) if (!sel.has(h)) return false; return true; };
  const chips = FAIXAS.map(f => `
    <button class="faixa ${faixaOn(f) ? 'sel' : ''}" data-faixa="${f.id}"><b>${f.nome}</b><small>${pad(f.ini)}h–${pad(f.fim)}h</small>${f.aviso ? `<em><svg class="ic-sm"><use href="#i-alerta"/></svg> ${f.aviso}</em>` : ''}</button>`).join('');
  const qualquer = sel.size === 24;
  let grade = '';
  if (S.mostrarGrade) for (let h = 0; h < 24; h++) grade += `<button class="hora ${sel.has(h) ? 'pref' : ''}" data-hsel="${h}">${pad(h)}h</button>`;
  return `<section class="bloco">
    <h2 class="pergunta-g">Quais horários servem?</h2>
    <p class="dica">Toque em uma ou mais faixas. Cada hora vale a hora inteira: 05h aceita de 05:00 a 05:59. Quer dar preferência a um horário? Deixe só ele aqui e crie outra opção com os demais.</p>
    <div class="faixas">${chips}</div>
    <div class="chips linha2">
      <button class="chip ${qualquer ? 'sel' : ''}" data-acao="qualquerHora">Qualquer horário</button>
      <button class="chip ${S.mostrarGrade ? 'sel' : ''}" data-acao="grade">Personalizar hora a hora</button>
    </div>
    ${qualquer ? '<div class="aviso-op"><svg class="ic-sm"><use href="#i-alerta"/></svg> Qualquer horário: pode marcar de madrugada ou à noite.</div>' : ''}
    ${S.mostrarGrade ? `<div class="horas">${grade}</div>` : ''}
    ${sel.size ? `<div class="sel-horas">Selecionado: <b>${esc(txtHoras([...sel].sort((a, b) => a - b)))}</b></div>` : ''}
  </section>`;
}

function blocoCalendario(o) {
  const { y, m } = S.cal;
  const hoje = hojeZero().getTime();
  const agora = new Date();
  const podeVoltar = y > agora.getFullYear() || (y === agora.getFullYear() && m > agora.getMonth());
  const primeiro = new Date(y, m, 1).getDay();
  const total = new Date(y, m + 1, 0).getDate();
  const sel = new Set((o.datas || []).map(d => `${d.y}-${d.m}-${d.d}`));
  let cel = SEMANA.map(s => `<div class="cal-sem">${s}</div>`).join('');
  for (let i = 0; i < primeiro; i++) cel += '<div></div>';
  for (let d = 1; d <= total; d++) {
    const t = new Date(y, m, d).getTime();
    const chave = `${y}-${m + 1}-${d}`;
    cel += `<button class="cal-dia ${sel.has(chave) ? 'sel' : ''} ${t === hoje ? 'hoje' : ''}" data-dia="${chave}" ${t < hoje ? 'disabled' : ''}>${d}</button>`;
  }
  const ds = datasFuturas(o);
  return `<div class="cal-topo">
      <button class="cal-nav" data-nav="-1" ${podeVoltar ? '' : 'disabled'}><svg class="ic"><use href="#i-esq"/></svg></button>
      <span class="cal-mes">${MESES[m]} ${y}</span>
      <button class="cal-nav" data-nav="1"><svg class="ic"><use href="#i-dir"/></svg></button>
    </div>
    <div class="cal-grade">${cel}</div>
    <div class="selecionadas">${ds.length ? `Selecionados: <b>${ds.map(fmtData).join(', ')}</b> <button class="link-inline" data-acao="limparDatas">limpar</button>` : 'Toque nos dias que servem.'}</div>`;
}

// ================= tela: resumo =================
function telaResumo() {
  const cfg = S.ed;
  const pend = pendencias(cfg);
  let situ = '';
  const auto = !pend.length && !S.autoCancelado;
  if (S.sitCarregando) situ = `<div class="banner info"><svg class="ic-sm"><use href="#i-ampulheta"/></svg> Conferindo a situação do envio no Mercado Livre…${auto ? '<div class="banner-meta">Se não houver agendamento, inicia sozinho.</div><button class="btn mini" data-acao="cancelarAuto">Cancelar início automático</button>' : ''}</div>`;
  else if (S.sit && !S.sit.ok) situ = `<div class="banner alerta"><b>Não consegui conferir o envio no ML.</b><div class="banner-meta">${esc(S.sit.erro || '')}</div></div>`;
  else if (S.sit && S.sit.envio) situ = `<div class="banner alerta"><b><svg class="ic-sm"><use href="#i-alerta"/></svg> Este envio JÁ está agendado</b><div class="banner-meta">${esc(S.sit.envio.replace(/^Você vai enviar estoque\s*/i, ''))}${S.sit.centro ? ` · ${esc(S.sit.centro)}` : ''}</div><div class="banner-meta">Se continuar, a extensão vai tentar <b>trocar</b> a reserva quando achar vaga numa das opções.</div></div>`;
  else if (S.sit && S.sit.ok) situ = `<div class="banner on"><svg class="ic-sm"><use href="#i-circ-check"/></svg> Conferido: este envio ainda não tem agendamento.${S.iniciando ? ' Iniciando…' : ''}</div>`;
  const jaAgendado = S.sit && S.sit.envio;
  const ops = cfg.opcoes.map((o, i) => `
    <section class="bloco">
      <h3><span class="n">${i + 1}</span>Opção ${i + 1} ${i === 0 ? '<small class="h-sub">tenta primeiro</small>' : `<small class="h-sub">só se a opção ${i} não tiver vaga</small>`}</h3>
      ${htmlLinhas(linhasOpcao(o))}
      ${htmlAvisos(avisosOpcao(o))}
    </section>`).join('');
  return `
    <div class="ed-topo">
      <button class="voltar" data-acao="envio"><svg class="ic"><use href="#i-esq"/></svg></button>
      <div class="ed-tit"><span class="ed-num">Envio <b>#${esc(S.num)}</b></span><span class="passo-txt">Revisão</span></div>
    </div>
    <h2 class="pergunta-g fora">Está certo?</h2>
    <p class="dica">Vou marcar <b>sozinho</b> o primeiro horário que encaixar, seguindo a ordem das opções:</p>
    ${ops}
    ${htmlAvisos(avisosGerais(cfg))}
    ${situ}
    ${S.sitCarregando ? '' : bannerTrava(S.envs[S.num], cfg)}
    ${S.erroIniciar ? `<div class="banner erro"><b>${svg('circ-x', 'ic-sm')} Não iniciou</b><div class="banner-meta">Motivo: ${esc(S.erroIniciar)}</div><div class="banner-meta">Tente de novo. Se repetir, mande um print desta mensagem.</div></div>` : ''}
    ${pend.length ? `<div class="falta">Falta completar: ${esc(pend.join(' · '))}</div>` : ''}
    <div class="acoes um">
      <button class="btn sucesso largo" data-acao="iniciar" ${pend.length || S.sitCarregando || S.iniciando ? 'disabled' : ''}>${S.iniciando ? '<svg class="ic-xs"><use href="#i-ampulheta"/></svg> Iniciando…' : jaAgendado ? '<svg class="ic-xs cheio"><use href="#i-play"/></svg> Entendi, tentar trocar a reserva' : '<svg class="ic-xs cheio"><use href="#i-play"/></svg> Está certo, iniciar'}</button>
    </div>
    <div class="acoes">
      <button class="btn" data-acao="envio">Corrigir</button>
      <button class="btn" data-acao="envio">Salvar sem iniciar</button>
    </div>
    ${S.modalAgendado && S.sit && S.sit.envio ? `<div class="modal-fundo"><div class="modal">
      <h3>${svg('alerta', 'ic-sm')} Este envio já tem agendamento</h3>
      <p class="modal-agenda">${esc(S.sit.envio.replace(/^Você vai enviar estoque\s*/i, ''))}${S.sit.centro ? ` · ${esc(S.sit.centro)}` : ''}</p>
      <p>Se prosseguir, a extensão vai procurar <b>outra data</b> nas suas opções e, quando achar, <b>troca</b> este agendamento pelo novo. Até lá, o atual continua valendo.</p>
      <button class="btn sucesso largo" data-acao="iniciar">Prosseguir e trocar a data</button>
      <button class="btn largo" data-acao="manterAgenda">Manter o agendamento atual</button>
    </div></div>` : ''}`;
}

// ================= tela: termo de uso =================
// Aparece antes de tudo enquanto não houver aceite; depois pode ser relido pelo link da primeira tela.
function telaTermo() {
  const ok = aceitou();
  const itens = TERMO.map(([t, txt]) => `<li><b>${esc(t)}</b> ${esc(txt)}</li>`).join('');
  return `
    ${ok ? '<div class="ed-topo"><button class="voltar" data-acao="inicio"><svg class="ic"><use href="#i-esq"/></svg></button><div class="ed-tit"><span class="ed-num">Termo de uso</span></div></div>' : ''}
    <div class="banner alerta"><b><svg class="ic-sm"><use href="#i-alerta"/></svg> Versão de teste — uso por sua conta e risco</b>
      <div class="banner-meta">O Agendador Full é oferecido como está, sem garantia. Ao usar, você declara que entende e aceita:</div></div>
    <section class="bloco"><ol class="termo-lista">${itens}</ol></section>
    ${ok ? `<p class="dica centro">Você aceitou em ${esc(new Date(S.termo.ts).toLocaleString('pt-BR'))} (termo versão ${esc(S.termo.versao)}).</p>` : `
      <label class="termo-check"><input type="checkbox" id="chkTermo" ${S.termoMarcado ? 'checked' : ''}><span>Li, entendi e aceito usar por minha conta e risco.</span></label>
      <div class="acoes um"><button class="btn sucesso largo" data-acao="aceitarTermo" ${S.termoMarcado ? '' : 'disabled'}>Aceitar e começar</button></div>`}`;
}

// ================= tela: login =================
// E-mail do cadastro → código de 6 dígitos por e-mail. Só é pedido em computador novo ou depois de "Sair".
const FIM_SESSAO = {
  outro_computador: 'Sua conta entrou em outro computador, então este foi desconectado.',
  derrubado: 'O administrador encerrou o seu acesso.',
  bloqueado: 'Seu acesso está bloqueado. Fale com o suporte.',
  sessao_invalida: 'Seu acesso expirou.'
};
const ERRO_LOGIN = {
  email_invalido: 'Confira o e-mail digitado.',
  nao_cadastrado: 'Este e-mail não tem cadastro. Cadastre-se no site primeiro.',
  bloqueado: 'Este acesso está bloqueado. Fale com o suporte.',
  muitos_pedidos: 'Limite de 3 códigos por dia para este e-mail. Tente amanhã.',
  limite_geral: 'Limite diário de códigos atingido. Tente mais tarde.',
  codigo_errado: 'Código errado.',
  codigo_expirado: 'Código expirado. Peça outro.',
  muitas_tentativas: 'Muitas tentativas erradas. Peça outro código.',
  falha_servidor: 'O servidor não respondeu. Tente de novo em instantes.'
};
function telaLogin() {
  const L = S.login;
  const motivo = S.conta && S.conta.motivo && FIM_SESSAO[S.conta.motivo];
  if (!L.email && S.conta && S.conta.email) L.email = S.conta.email;
  return `
    ${motivo ? `<div class="banner alerta"><b><svg class="ic-sm"><use href="#i-cadeado"/></svg> ${esc(motivo)}</b><div class="banner-meta">Entre de novo para continuar usando neste computador.</div></div>` : ''}
    <section class="bloco">
      <h2 class="pergunta-g">Entrar no Agendador</h2>
      ${L.etapa === 'email' ? `
        <p class="dica">Use o e-mail do seu cadastro. Vamos mandar um código de 6 dígitos para ele.</p>
        <input id="inLoginEmail" type="email" placeholder="seu@email.com" value="${esc(L.email)}" autocomplete="email">
        <div class="acoes um" style="margin-top:10px"><button class="btn primario largo" data-acao="loginCodigo" ${L.ocupado ? 'disabled' : ''}>${L.ocupado ? 'Enviando…' : 'Enviar código'}</button></div>`
      : `
        <p class="dica">Digite o código enviado para <b>${esc(L.email)}</b>. Ele vale 10 minutos.</p>
        <input id="inLoginCodigo" inputmode="numeric" maxlength="6" placeholder="000000" autocomplete="one-time-code" class="codigo">
        <div class="acoes um" style="margin-top:10px"><button class="btn sucesso largo" data-acao="loginEntrar" ${L.ocupado ? 'disabled' : ''}>${L.ocupado ? 'Entrando…' : 'Entrar'}</button></div>
        <button class="link" data-acao="loginVoltar">Trocar e-mail ou pedir outro código</button>`}
      ${L.msg ? `<div class="${L.tipoMsg === 'erro' ? 'erro-msg' : 'banner info'}" style="margin-top:10px">${esc(L.msg)}</div>` : ''}
    </section>
    <p class="dica centro">Ainda não tem cadastro? <button class="link-inline" data-acao="abrirSite">Cadastre-se no site</button></p>
    <p class="dica centro">O acesso vale para um computador por vez: entrar aqui encerra o acesso em outro computador.</p>`;
}

async function loginCodigo() {
  const L = S.login;
  L.email = (($('#inLoginEmail') || {}).value || L.email || '').trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(L.email)) { Object.assign(L, { msg: 'Digite um e-mail válido.', tipoMsg: 'erro' }); return render(); }
  Object.assign(L, { ocupado: true, msg: '' }); render();
  const r = await enviar({ tipo: 'pedirCodigo', email: L.email });
  L.ocupado = false;
  if (r.ok) Object.assign(L, { etapa: 'codigo', msg: 'Código enviado. Confira o seu e-mail (veja também o spam).', tipoMsg: 'info' });
  else Object.assign(L, { msg: ERRO_LOGIN[r.erro] || r.erro || 'Não consegui enviar o código.', tipoMsg: 'erro' });
  render();
  const c = $('#inLoginCodigo'); if (c) c.focus();
}
async function loginEntrar() {
  const L = S.login;
  const codigo = (($('#inLoginCodigo') || {}).value || '').replace(/\D/g, '');
  if (codigo.length !== 6) { Object.assign(L, { msg: 'O código tem 6 dígitos.', tipoMsg: 'erro' }); return render(); }
  Object.assign(L, { ocupado: true, msg: '' }); render();
  const r = await enviar({ tipo: 'entrar', email: L.email, codigo });
  L.ocupado = false;
  if (!r.ok) {
    Object.assign(L, { msg: (ERRO_LOGIN[r.erro] || r.erro || 'Não consegui entrar.') + (r.restam != null ? ` Restam ${r.restam} tentativa(s).` : ''), tipoMsg: 'erro' });
    return render();
  }
  S.login = { email: '', etapa: 'email', msg: '', tipoMsg: '', ocupado: false };
  await carregar();
  ir('lista');
}

// ================= render =================
function render() {
  const app = $('#app');
  const topo = app.scrollTop;
  const det = app.querySelector('details.log');
  if (det) S.logAberto = det.open;
  if (['envio', 'opcao', 'resumo'].includes(S.tela) && !S.envs[S.num]) S.tela = 'lista';
  if (!aceitou()) S.tela = 'termo';
  else if (!logado()) S.tela = 'login';
  const mapa = { lista: telaLista, notifs: telaNotifs, notif: telaNotif, envio: telaEnvio, opcao: telaOpcao, resumo: telaResumo, termo: telaTermo, login: telaLogin };
  app.innerHTML = (mapa[S.tela] || telaLista)();
  app.scrollTop = topo;
  const nl = naoLidas().length;
  const cont = $('#contNotifs');
  cont.hidden = !nl;
  cont.textContent = nl > 9 ? '9+' : String(nl);
}
function ir(tela, extra = {}) {
  Object.assign(S, { tela }, extra);
  render();
  $('#app').scrollTop = 0;
}
function abrirEnvio(num) {
  const e = S.envs[num];
  if (!e) return;
  S.num = num;
  S.ed = migrar(clonar(e.cfg));
  S.logAberto = false;
  ir('envio');
}
function editarOpcao(i, passo = 1) {
  S.op = i;
  const o = opAtual();
  const ds = datasFuturas(o);
  const base = ds.length ? new Date(ds[0].y, ds[0].m - 1, 1) : new Date();
  S.cal = { y: base.getFullYear(), m: base.getMonth() };
  S.mostrarGrade = false;
  ir('opcao', { passo });
}
async function irResumo() {
  await salvarCfgAgora();
  S.sit = null;
  S.erroIniciar = '';
  S.autoCancelado = false;
  S.modalAgendado = false;
  S.sitCarregando = true;
  const num = S.num;
  ir('resumo');
  const r = await enviar({ tipo: 'situacao', num });
  S.sitCarregando = false;
  S.sit = r;
  if (S.tela !== 'resumo' || S.num !== num) return;
  const pronto = !pendencias(S.ed).length && !S.autoCancelado;
  if (pronto && r.ok && !r.envio) return iniciarDoBotao();
  if (pronto && r.ok && r.envio) S.modalAgendado = true;
  render();
}

// ================= ações =================
const app = $('#app');

// Inicia o envio da revisão (pelo clique, pelo plano B ou sozinho depois de conferir).
async function iniciarDoBotao() {
  if (S.iniciando) return;
  S.iniciando = true;
  S.cliqueIniciar = true;
  S.modalAgendado = false;
  render();
  S.erroIniciar = '';
  try {
    await salvarCfgAgora();
    let r = await enviar({ tipo: 'iniciar', num: S.num });
    // Falha de comunicação: tenta mais uma vez antes de mostrar o erro.
    if (!r.ok && r.semResposta) { await new Promise(ok => setTimeout(ok, 700)); r = await enviar({ tipo: 'iniciar', num: S.num }); }
    if (!r.ok) {
      S.erroIniciar = r.erro || 'motivo desconhecido';
      if (r.semResposta) enviar({ tipo: 'logFalha', num: S.num, erro: S.erroIniciar });
      return;
    }
    await carregar();
    return abrirEnvio(S.num);
  } catch (err) {
    S.erroIniciar = 'erro no popup: ' + ((err && err.message) || err);
  } finally {
    S.iniciando = false;
    if (S.tela === 'resumo') render();
  }
}

app.addEventListener('click', async ev => {
  const t = ev.target.closest('[data-acao],[data-abrir],[data-parar],[data-notif],[data-opeditar],[data-opmover],[data-opapagar],[data-irpasso],[data-forma],[data-cd],[data-mover],[data-dia],[data-hsel],[data-faixa],[data-nav],[data-dmodo],[data-dn],[data-vinc]');
  if (!t || t.disabled) return;
  const d = t.dataset;

  if (d.parar) { ev.stopPropagation(); await enviar({ tipo: 'parar', num: d.parar }); return; }
  if (d.notif) {
    S.notifId = d.notif;
    const n = S.notifs.find(x => x.id === d.notif);
    if (n && !n.lida) enviar({ tipo: 'lidas', ids: [n.id] });
    return ir('notif');
  }
  if (d.abrir) return abrirEnvio(d.abrir);

  if (S.tela === 'envio' && S.ed) {
    if (d.vinc) {
      const g = S.envs[S.num].grupo;
      const r = await enviar({ tipo: 'vincular', num: S.num, com: d.vinc, ligar: !(g && S.envs[d.vinc].grupo === g) });
      if (!r.ok) alert(r.erro || 'Não consegui mudar o vínculo.');
      return;
    }
    if (d.opeditar !== undefined) return editarOpcao(+d.opeditar);
    if (d.opmover !== undefined) {
      const i = +d.opmover, j = i + Number(d.dir), ops = S.ed.opcoes;
      if (j >= 0 && j < ops.length) [ops[i], ops[j]] = [ops[j], ops[i]];
      await salvarCfgAgora(); return render();
    }
    if (d.opapagar !== undefined) {
      if (!confirm(`Apagar a opção ${+d.opapagar + 1}?`)) return;
      S.ed.opcoes.splice(+d.opapagar, 1);
      await salvarCfgAgora(); return render();
    }
  }

  if (S.tela === 'opcao' && S.ed && opAtual()) {
    const o = opAtual();
    if (d.irpasso) return ir('opcao', { passo: +d.irpasso });
    if (d.forma) { o.tipoEnvio = d.forma; salvarCfg(); return render(); }
    if (d.cd) {
      const i = o.cds.indexOf(d.cd);
      if (i >= 0) o.cds.splice(i, 1); else o.cds.push(d.cd);
      salvarCfg(); return render();
    }
    if (d.mover !== undefined) {
      const i = +d.mover, j = i + Number(d.dir);
      if (j >= 0 && j < o.cds.length) [o.cds[i], o.cds[j]] = [o.cds[j], o.cds[i]];
      salvarCfg(); return render();
    }
    if (d.dmodo) {
      o.datasModo = d.dmodo;
      if (d.dmodo === 'proximos' && ![3, 7, 15].includes(o.datasN)) o.datasN = 7;
      salvarCfg(); return render();
    }
    if (d.dn) { o.datasN = +d.dn; salvarCfg(); return render(); }
    if (d.dia) {
      const [y, m, dd] = d.dia.split('-').map(Number);
      const i = o.datas.findIndex(x => x.y === y && x.m === m && x.d === dd);
      if (i >= 0) o.datas.splice(i, 1); else o.datas.push({ y, m, d: dd });
      o.datas = datasFuturas(o);
      salvarCfg(); return render();
    }
    if (d.nav) {
      const nm = S.cal.m + Number(d.nav);
      S.cal = { y: S.cal.y + Math.floor(nm / 12), m: ((nm % 12) + 12) % 12 };
      return render();
    }
    if (d.faixa) {
      const f = FAIXAS.find(x => x.id === d.faixa);
      let todas = true;
      for (let h = f.ini; h <= f.fim; h++) if (!o.horas[String(h)]) todas = false;
      for (let h = f.ini; h <= f.fim; h++) { if (todas) delete o.horas[String(h)]; else o.horas[String(h)] = 1; }
      salvarCfg(); return render();
    }
    if (d.hsel !== undefined) {
      const k = String(d.hsel);
      if (o.horas[k]) delete o.horas[k]; else o.horas[k] = 1;
      salvarCfg(); return render();
    }
  }

  switch (d.acao) {
    case 'inicio': return ir('lista');
    case 'termo': return ir('termo');
    case 'loginCodigo': return loginCodigo();
    case 'loginEntrar': return loginEntrar();
    case 'loginVoltar': Object.assign(S.login, { etapa: 'email', msg: '' }); return render();
    case 'abrirSite': chrome.tabs.create({ url: SITE }); return;
    case 'sair': {
      const ativos = S.lista.filter(n => S.envs[n] && S.envs[n].ativo).length;
      if (!confirm(ativos ? `Sair da conta? Os ${ativos} envio(s) monitorando vão parar.` : 'Sair da conta neste computador?')) return;
      await enviar({ tipo: 'sair' });
      await carregar();
      return ir('login');
    }
    case 'aceitarTermo': {
      if (!S.termoMarcado) return;
      await enviar({ tipo: 'aceitarTermo', versao: TERMO_VERSAO });
      await carregar();
      return ir('lista');
    }
    case 'envio': await salvarCfgAgora(); await carregar(); return abrirEnvio(S.num);
    case 'notifs': return ir('notifs');
    case 'todasLidas': await enviar({ tipo: 'lidas' }); return;
    case 'limparNotifs':
      if (confirm('Apagar o histórico de notificações?')) await enviar({ tipo: 'limparNotifs' });
      return;
    case 'som': await enviar({ tipo: 'glob', patch: { som: !S.glob.som } }); return;
    case 'testarSom': await enviar({ tipo: 'testarSom', som: 'sucesso' }); return;
    case 'abrirML': await enviar({ tipo: 'abrirML', num: d.num || S.num }); return;
    case 'pararTodos': await enviar({ tipo: 'pararTodos' }); return;
    case 'addAba': {
      const r = await enviar({ tipo: 'adicionar', num: S.numAba, url: S.urlAba });
      S.erroAdd = r.ok ? '' : r.erro;
      await carregar();
      if (!r.ok) return render();
      abrirEnvio(S.numAba);
      return novaOpcao();
    }
    case 'addManual': return addManual();
    case 'addCd': return addCd();
    case 'novaOpcao': return novaOpcao();
    case 'duplicar': {
      if (S.ed.opcoes.length >= MAX_OPCOES || !S.ed.opcoes.length) return;
      S.ed.opcoes.push(clonar(S.ed.opcoes[S.ed.opcoes.length - 1]));
      await salvarCfgAgora();
      return editarOpcao(S.ed.opcoes.length - 1);
    }
    case 'edAvancar': await salvarCfgAgora(); return ir('opcao', { passo: Math.min(PASSOS.length, S.passo + 1) });
    case 'edVoltar': return ir('opcao', { passo: Math.max(1, S.passo - 1) });
    case 'salvarOpcao': await salvarCfgAgora(); await carregar(); return abrirEnvio(S.num);
    case 'revisar': return irResumo();
    case 'qualquerHora': {
      const o = opAtual();
      const todas = horasSel(o).length === 24;
      o.horas = {};
      if (!todas) for (let h = 0; h < 24; h++) o.horas[String(h)] = 1;
      salvarCfg(); return render();
    }
    case 'grade': S.mostrarGrade = !S.mostrarGrade; return render();
    case 'limparDatas': opAtual().datas = []; salvarCfg(); return render();
    case 'testar':
      await salvarCfgAgora();
      await enviar({ tipo: 'testar', num: S.num });
      S.logAberto = true;
      return;
    case 'iniciar': return iniciarDoBotao();
    case 'cancelarAuto': S.autoCancelado = true; return render();
    case 'manterAgenda': S.modalAgendado = false; return abrirEnvio(S.num);
    case 'parar': await enviar({ tipo: 'parar', num: S.num }); return;
    case 'remover':
      if (!confirm(`Remover o envio #${S.num} da lista?`)) return;
      await enviar({ tipo: 'remover', num: S.num });
      await carregar();
      return ir('lista');
  }
});

async function novaOpcao() {
  if (S.ed.opcoes.length >= MAX_OPCOES) return;
  S.ed.opcoes.push(opcaoPadrao());
  await salvarCfgAgora();
  return editarOpcao(S.ed.opcoes.length - 1);
}

app.addEventListener('keydown', ev => {
  if (ev.key === 'Enter' && ev.target.classList.contains('card')) return abrirEnvio(ev.target.dataset.abrir);
  if (ev.key !== 'Enter') return;
  if (ev.target.id === 'inNum') addManual();
  if (ev.target.id === 'inLoginEmail') loginCodigo();
  if (ev.target.id === 'inLoginCodigo') loginEntrar();
  if (ev.target.id === 'inCd' || ev.target.id === 'inCdNome') addCd();
});

async function addManual() {
  const num = ($('#inNum').value || '').replace(/\D/g, '');
  if (!num) { S.erroAdd = 'Digite o número do envio.'; return render(); }
  const r = await enviar({ tipo: 'adicionar', num });
  S.erroAdd = r.ok ? '' : r.erro;
  await carregar();
  if (!r.ok) return render();
  abrirEnvio(num);
  return novaOpcao();
}

async function addCd() {
  const cod = ($('#inCd').value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const nome = ($('#inCdNome') ? $('#inCdNome').value : '').trim();
  if (cod.length < 4) return;
  await enviar({ tipo: 'centro', cod, nome });
  const o = opAtual();
  if (!o.cds.includes(cod)) o.cds.push(cod);
  salvarCfg();
  await carregar();
  render();
}

app.addEventListener('change', async ev => {
  const t = ev.target;
  if (t.id === 'chkTermo') { S.termoMarcado = t.checked; return render(); }
  if (t.id === 'selInt') await enviar({ tipo: 'glob', patch: { intervalo: Number(t.value) } });
  if (t.id === 'inAte') await enviar({ tipo: 'glob', patch: { ate: t.value } });
  if (t.id === 'inDataAte' && S.ed && opAtual()) {
    const [y, m, d] = (t.value || '').split('-').map(Number);
    opAtual().datasAte = y ? { y, m, d } : null;
    salvarCfg(); render();
  }
  if (t.id === 'selCopiar' && t.value && S.envs[t.value]) {
    if (S.ed.opcoes.length && !confirm(`Substituir as opções deste envio pelas do envio #${t.value}?`)) { t.value = ''; return; }
    S.ed = migrar(clonar(S.envs[t.value].cfg));
    await salvarCfgAgora();
    await carregar();
    render();
  }
});

$('#btnNotifs').addEventListener('click', () => ir('notifs'));
$('#btnInicio').addEventListener('click', () => ir('lista'));

// Atualiza a tela quando o background muda algo. Não redesenha durante a digitação
// nem sobrescreve a opção que está sendo editada.
// Redesenhar entre o apertar e o soltar do mouse troca o botão e o clique se perde:
// enquanto o botão do mouse está apertado, a atualização espera.
app.addEventListener('pointerdown', ev => {
  S.apertado = true;
  const b = ev.target.closest && ev.target.closest('[data-acao="iniciar"]');
  S.apertouIniciar = !!b;
});
addEventListener('pointerup', ev => {
  if (!S.apertado) return;
  S.apertado = false;
  if (S.apertouIniciar && S.tela === 'resumo') {
    S.apertouIniciar = false;
    const sob = document.elementFromPoint(ev.clientX, ev.clientY);
    const b = sob && sob.closest('[data-acao="iniciar"]');
    if (b && !b.disabled) {
      S.cliqueIniciar = false;
      setTimeout(() => {
        if (S.cliqueIniciar || S.tela !== 'resumo') return;
        iniciarDoBotao();
      }, 400);
    }
  }
  if (S.renderAdiado) { S.renderAdiado = false; setTimeout(render, 0); }
});
chrome.storage.onChanged.addListener(async () => {
  await carregar();
  if ((S.tela === 'envio' || S.tela === 'lista') && S.num && S.envs[S.num]) S.ed = migrar(clonar(S.envs[S.num].cfg));
  if (S.apertado) { S.renderAdiado = true; return; }
  // Na revisão o botão fica parado: só redesenha por ação sua ou ao terminar a conferência.
  if (S.tela === 'resumo') return;
  const foco = document.activeElement;
  if (foco && app.contains(foco) && /INPUT|SELECT/.test(foco.tagName)) {
    if (!S.pendente) {
      S.pendente = true;
      foco.addEventListener('blur', () => { S.pendente = false; render(); }, { once: true });
    }
    return;
  }
  render();
});

(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.url) {
    S.urlAba = tab.url;
    try {
      const u = new URL(tab.url);
      const m = /mercadoli(vre|bre)/.test(u.hostname) && u.pathname.match(/\/inbounds\/(\d{5,})/);
      S.numAba = m ? m[1] : null;
    } catch (e) { S.numAba = null; }
  }
  await carregar();
  render();
})();
