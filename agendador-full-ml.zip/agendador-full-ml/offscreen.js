// Toca os alertas sonoros (o service worker não consegue tocar áudio sozinho).
const SONS = {
  sucesso: [[660, 0], [880, 0.15], [1175, 0.3], [880, 0.7], [1175, 0.85], [1568, 1.0]],
  falha: [[440, 0], [330, 0.3], [440, 0.8], [330, 1.1]]
};

function tocar(tipo) {
  const notas = SONS[tipo] || SONS.sucesso;
  const ctx = new AudioContext();
  for (const [freq, t] of notas) {
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = 'sine';
    o.frequency.value = freq;
    const ini = ctx.currentTime + t;
    g.gain.setValueAtTime(0.0001, ini);
    g.gain.exponentialRampToValueAtTime(0.4, ini + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, ini + 0.28);
    o.connect(g).connect(ctx.destination);
    o.start(ini);
    o.stop(ini + 0.3);
  }
  setTimeout(() => ctx.close(), 2500);
}

chrome.runtime.onMessage.addListener(msg => {
  if (msg && msg.alvo === 'offscreen') tocar(msg.som);
});
