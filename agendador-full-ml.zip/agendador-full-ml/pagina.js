// Passos executados DENTRO da página do Mercado Livre.
// Esta função é injetada pelo background a cada passo. Ela não espera nada
// (sem timers): quem espera é o background, que não sofre com a lentidão
// que o Chrome impõe às abas em segundo plano.
function fbPasso(acao, a) {
  const norm = s => (s || '').replace(/\s+/g, ' ').trim();
  const main = document.querySelector('main') || document.body;
  const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
  const botoes = (raiz, texto) => [...raiz.querySelectorAll('button')].filter(b => norm(b.innerText) === texto);
  const trigger = () => document.getElementById('shipment-type-selection-dropdown-id-trigger');
  const campoData = () => document.querySelector('[data-testid=date-time-picker-input]');
  const listaCentros = () => [...document.querySelectorAll('button.andes-list__item-action')].filter(b => /Centro log/i.test(b.innerText));
  const alvo = () => document.querySelector('[data-fullbot=alvo]');

  function confirmarCalendario() {
    let n = alvo();
    while (n && n !== document.body) {
      const b = botoes(n, 'Confirmar')[0];
      if (b) return b;
      n = n.parentElement;
    }
    return null;
  }

  function centroFixo() {
    const t = main.innerText || '';
    const m = t.match(/agendamento\s*\n\s*(Centro[^\n]*)/);
    if (m) return norm(m[1]);
    const linha = t.split('\n').find(l => /Centro log[íi]stico/i.test(l) && /BR[A-Z]{2}\d{2}/.test(l));
    return linha ? norm(linha) : '';
  }

  function elemento(qual) {
    return qual === 'alvo' ? alvo() : confirmarCalendario();
  }

  switch (acao) {
    case 'info': {
      const tr = trigger();
      return {
        url: location.href,
        trigger: !!tr,
        tipo: tr ? norm(tr.innerText) : '',
        centros: listaCentros().map(b => norm(b.innerText)),
        campo: !!campoData(),
        centroFixo: centroFixo(),
        semDatas: /não temos datas disponíveis|nao temos datas disponiveis|tente novamente nos próximos dias/i.test(document.body.innerText || ''),
        login: /\/jms\/|\/lgz\/|\/login|\/registration/i.test(location.href) || !!document.querySelector('input[name=user_id], #user_id')
      };
    }
    case 'abrirTipo': {
      const tr = trigger();
      if (!tr) return false;
      tr.click();
      return true;
    }
    case 'escolherTipo': {
      const opt = [...document.querySelectorAll('[role=option], li')].find(e => norm(e.innerText).startsWith(a));
      if (!opt) return false;
      if (opt.getAttribute('aria-disabled') === 'true' || /indispon[íi]vel/i.test(opt.innerText)) return 'indisp';
      opt.click();
      return true;
    }
    case 'clicarCentro': {
      const b = listaCentros().find(x => norm(x.innerText) === a);
      if (!b) return false;
      b.click();
      return true;
    }
    case 'continuar': {
      const c = botoes(document, 'Continuar').find(b => !b.disabled);
      if (!c) return false;
      c.click();
      return true;
    }
    case 'abrirCalendario': {
      const i = campoData();
      if (!i) return false;
      i.click();
      return true;
    }
    case 'mes': {
      // Lê o título do mês do calendário ("outubro 2026").
      const d = document.querySelector('.day');
      if (!d) return null;
      const achar = t => MESES.filter(m => (t || '').toLowerCase().includes(m));
      const tit = document.querySelector('[class*=month-year]');
      if (tit && achar(tit.innerText).length) return achar(tit.innerText);
      // Plano B: sobe a partir do dia até achar um bloco que contenha o nome do mês.
      let n = d.parentElement;
      for (let i = 0; i < 8 && n && n !== document.body; i++, n = n.parentElement) {
        const r = achar(n.innerText);
        if (r.length) return r;
      }
      return null;
    }
    case 'navMes': {
      const b = document.querySelector(`button[aria-label="${a === 'prev' ? 'back' : 'next'} month"]`);
      if (!b || b.disabled) return false;
      b.click();
      return true;
    }
    case 'dia': {
      const ds = [...document.querySelectorAll('.day')];
      const i1 = ds.findIndex(x => x.textContent.trim() === '1');
      const el = ds.slice(Math.max(i1, 0)).find(x => x.textContent.trim() === String(a.d));
      if (!el) return 'nao';
      if (/disabled/.test(el.className)) return 'indisp';
      if (a.clicar) el.click();
      return 'ok';
    }
    case 'diasDisponiveis': {
      // Dias do mês visível que o ML deixa clicar (ignora os do mês anterior/seguinte).
      const ds = [...document.querySelectorAll('.day')];
      const i1 = ds.findIndex(x => x.textContent.trim() === '1');
      if (i1 < 0) return [];
      let fim = ds.length;
      for (let k = i1 + 1; k < ds.length; k++) if (ds[k].textContent.trim() === '1') { fim = k; break; }
      return ds.slice(i1, fim).filter(x => !/disabled/.test(x.className)).map(x => parseInt(x.textContent.trim(), 10));
    }
    case 'horas':
      return [...document.querySelectorAll('.hour-box')].map(b => norm(b.textContent));
    case 'marcarAlvo': {
      document.querySelectorAll('[data-fullbot]').forEach(e => e.removeAttribute('data-fullbot'));
      const b = [...document.querySelectorAll('.hour-box')].find(x => norm(x.textContent) === a);
      if (!b) return false;
      b.setAttribute('data-fullbot', 'alvo');
      return true;
    }
    case 'rolar': {
      const el = elemento(a);
      if (!el) return false;
      el.scrollIntoView({ block: 'center', inline: 'center', behavior: 'instant' });
      return true;
    }
    case 'rect': {
      const el = elemento(a);
      if (!el) return null;
      const r = el.getBoundingClientRect();
      if (!r.width || !r.height) return null;
      return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
    }
    case 'valorData': {
      const i = campoData();
      return i ? (i.value || i.innerText || '') : '';
    }
    case 'confirmarPrincipal': {
      const b = [...document.querySelectorAll('main button')].filter(x => norm(x.innerText) === 'Confirmar').pop();
      if (!b) return false;
      b.click();
      return true;
    }
    case 'verificar': {
      const t = document.body.innerText || '';
      return {
        reetiq: /etiquetar novamente/i.test(t),
        stale: /não está mais disponível|nao esta mais disponivel/i.test(t),
        hub: /\/inbounds\/\d+\/hub(-v2)?(?:[/?#]|$)/.test(location.href)
      };
    }
    case 'confirmarModal': {
      const dlg = document.querySelector('[role=dialog]') || document.body;
      const b = botoes(dlg, 'Confirmar').pop();
      if (!b) return false;
      b.click();
      return true;
    }
    case 'hub': {
      const t = document.body.innerText || '';
      return {
        carregado: /Envio #\d+/.test(t),
        envio: norm((t.match(/Você vai enviar estoque[^\n]*/) || [])[0] || ''),
        centro: norm((t.match(/Envio para:\s*(Centro log[íi]stico[^\n]*)/) || t.match(/(Centro log[íi]stico[^\n]*)/) || [])[1] || ''),
        prazo: norm((t.match(/Você poderá mudar[^\n]*/) || [])[0] || ''),
        etiquetas: /baixar novamente as etiquetas/i.test(t)
      };
    }
  }
  return null;
}
